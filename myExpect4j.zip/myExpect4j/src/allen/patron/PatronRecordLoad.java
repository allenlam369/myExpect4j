/**
 * Convert staff/student data file into patron record for INNOPAC loading
 * Insert uid and card barcode for Portal staff users if such fields do not exist.
 *
 * input data files: staff.dat, student.dat
 *
 * output files: staff_out.txt, student1_out.txt, student2_out.txt, staff_barcode.txt
 */
package allen.patron;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

public class PatronRecordLoad {
	static SimpleDateFormat dateFormatterInnopac = new SimpleDateFormat(
			"dd-MM-yy");

	// for testing
	public static void main(String[] args) {
		PatronRecord pr = PatronRecordLoad.getPatronRecord("62936");
		System.out.println(pr);
	}

	// public static enum DatType {
	// STAFF, STUDENT, STUDENT_EXP
	// }

	public static PatronRecord getPatronRecord(String uid) {
		String urlStr = "http://library.hku.hk:4500/PATRONAPI/" + uid + "/dump";
		try {
			URL url = new URL(urlStr);
			BufferedReader in = new BufferedReader(new InputStreamReader(url
					.openStream()));
			String str;
			StringBuilder sb = new StringBuilder();
			while ((str = in.readLine()) != null) {
				sb.append(str);
			}
			in.close();

			String sbStr = sb.toString();
			if (StringUtils.isEmpty(sbStr)
					|| sbStr.contains("Requested record not found")) {
				return null;
			}

			PatronRecord patronRec = processPatronRecord(sbStr);
			return patronRec;
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static PatronRecord processPatronRecord(String str) {

		if (str.contains("ERRNUM=1")) {
			return null;
		}

		PatronRecord pr = new PatronRecord();

		try {
			pr.setRecInfo(StringUtils.substringBetween(str, "[p!]=", "<BR>"));
			pr.setExpDate(dateFormatterInnopac.parse(StringUtils
					.substringBetween(str, "[p43]=", "<BR>")));
			pr.setPcode1(StringUtils.substringBetween(str, "[p44]=", "<BR>"));
			pr.setPcode2(StringUtils.substringBetween(str, "[p45]=", "<BR>"));
			pr.setPcode3(StringUtils.substringBetween(str, "[p46]=", "<BR>"));
			pr.setPtype(StringUtils.substringBetween(str, "[p47]=", "<BR>"));
			pr.setTotChkout(Integer.parseInt(StringUtils.substringBetween(str,
					"[p48]=", "<BR>")));
			pr.setTotRenwal(Integer.parseInt(StringUtils.substringBetween(str,
					"[p49]=", "<BR>")));
			pr.setCurChkout(Integer.parseInt(StringUtils.substringBetween(str,
					"[p50]=", "<BR>")));
			pr.setHomeLibr(StringUtils.substringBetween(str, "[p53]=", "<BR>"));
			pr.setpMessage(StringUtils.substringBetween(str, "[p54]=", "<BR>"));
			pr.setHloDues(Integer.parseInt(StringUtils.substringBetween(str,
					"[p55]=", "<BR>")));
			pr.setMblock(StringUtils.substringBetween(str, "[p56]=", "<BR>")
					.charAt(0));
			pr.setRecType(StringUtils.substringBetween(str, "[p80]=", "<BR>")
					.charAt(0));
			pr.setRecordNum(Integer.parseInt(StringUtils.substringBetween(str,
					"[p81]=", "<BR>")));
			pr.setRecLeng(Integer.parseInt(StringUtils.substringBetween(str,
					"[p82]=", "<BR>")));
			pr.setCreated(dateFormatterInnopac.parse(StringUtils
					.substringBetween(str, "[p83]=", "<BR>")));
			pr.setUpdated(dateFormatterInnopac.parse(StringUtils
					.substringBetween(str, "[p84]=", "<BR>")));
			pr.setRevisions(Integer.parseInt(StringUtils.substringBetween(str,
					"[p85]=", "<BR>")));
			pr.setAgency(Integer.parseInt(StringUtils.substringBetween(str,
					"[p86]=", "<BR>")));
			pr.setClRtrnd(Integer.parseInt(StringUtils.substringBetween(str,
					"[p95]=", "<BR>")));
			// remove comma, e.g. 12,345 to become 12345
			String owed = StringUtils.substringBetween(str, "[p96]=$", "<BR>");
			owed = owed.replaceAll(",", "");
			pr.setMoneyOwed(Double.parseDouble(owed));
			pr
					.setBlkUntil(StringUtils.substringBetween(str, "[p101]=",
							"<BR>"));
			pr.setCurItema(Integer.parseInt(StringUtils.substringBetween(str,
					"[p102]=", "<BR>")));
			pr.setCurItemb(Integer.parseInt(StringUtils.substringBetween(str,
					"[p103]=", "<BR>")));
			pr.setPiUse(Integer.parseInt(StringUtils.substringBetween(str,
					"[p104]=", "<BR>")));
			pr.setOdPenalty(Integer.parseInt(StringUtils.substringBetween(str,
					"[p105]=", "<BR>")));
			pr.setIllChkout(Integer.parseInt(StringUtils.substringBetween(str,
					"[p122]=", "<BR>")));
			// sometimes the date string will be "  -  -  "
			String d = StringUtils.substringBetween(str, "[p163]=", "<BR>");
			try {
				pr.setCircActive(dateFormatterInnopac.parse(d));
			} catch (ParseException e) {
				pr.setCircActive(null);
			}
			pr.setNoticePref(StringUtils.substringBetween(str, "[p268]=",
					"<BR>").charAt(0));
			String[] ss = StringUtils.substringsBetween(str, "[p8]=", "<BR>");
			if (ss != null) {
				for (String s : ss) {
					pr.holdList.add(s);
				}
			}
			pr
					.setPatronName(StringUtils.substringBetween(str, "[pn]=",
							"<BR>"));
			pr.setAddress(StringUtils.substringBetween(str, "[pa]=", "<BR>"));
			pr.setMobile(StringUtils.substringBetween(str, "[pr]=", "<BR>"));
			pr.setIdNo(StringUtils.substringBetween(str, "[pf]=", "<BR>"));
			pr.setUnivId(StringUtils.substringBetween(str, "[pu]=", "<BR>"));
			pr.setPin(StringUtils.substringBetween(str, "[p=]=", "<BR>"));
			pr.setEmailAddr(StringUtils.substringBetween(str, "[pz]=", "<BR>"));
			String sex = StringUtils.substringBetween(str, "[ps]=", "<BR>");
			if (sex != null && sex.length() > 0) {
				pr.setSex(sex.charAt(0));
			}
			pr.setDept(StringUtils.substringBetween(str, "[pj]=", "<BR>"));
			pr.setTitle(StringUtils.substringBetween(str, "[po]=", "<BR>"));
			pr.setPortal(StringUtils.substringBetween(str, "[pw]=", "<BR>"));
			String[] ss1 = StringUtils.substringsBetween(str, "[pb]=", "<BR>");
			if (ss1 != null) {
				for (String s : ss1) {
					pr.barcodeList.add(s);
				}
			}
			String linkrec = StringUtils.substringBetween(str, "[p^]=", "<BR>");
			if (linkrec != null && linkrec.length() > 0) {
				pr.setLinkrec(linkrec.charAt(0));
			}
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println(str);
			e.printStackTrace();
		}
		return pr;
	}
}
