package allen.patron;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatronRecord {
	private String recInfo;
	private Date expDate;
	private String pcode1;
	private String pcode2;
	private String pcode3;
	private String ptype;
	private int totChkout;
	private int totRenwal;
	private int curChkout;
	private String homeLibr;
	private String pMessage;
	private int hloDues;
	private char mblock;
	private char recType;
	private int recordNum;
	private int recLeng;
	private Date created;
	private Date updated;
	private int revisions;
	private int agency;
	private int clRtrnd;
	private double moneyOwed;
	private String blkUntil;
	private int curItema;
	private int curItemb;
	private int piUse;
	private int odPenalty;
	private int illChkout;
	private Date circActive;
	private char noticePref;
	List<String> holdList = new ArrayList<String>();
	private String patronName;
	private String address;
	private String mobile;
	private String idNo;
	private String univId;
	private String pin;
	private String emailAddr;
	private char sex;
	private String dept;
	private String title;
	private String portal;
	public List<String> barcodeList = new ArrayList<String>();
	private char linkrec;

	@Override
	public String toString() {
		return "PatronRecord [address=" + address + ", agency=" + agency
				+ ", barcode=" + barcodeList + ", blkUntil=" + blkUntil
				+ ", circActive=" + circActive + ", clRtrnd=" + clRtrnd
				+ ", created=" + created + ", curChkout=" + curChkout
				+ ", curItema=" + curItema + ", curItemb=" + curItemb
				+ ", dept=" + dept + ", emailAddr=" + emailAddr + ", expDate="
				+ expDate + ", hloDues=" + hloDues + ", holds=" + holdList
				+ ", homeLibr=" + homeLibr + ", idNo=" + idNo + ", illChkout="
				+ illChkout + ", linkrec=" + linkrec + ", mblock=" + mblock
				+ ", mobile=" + mobile + ", moneyOwed=" + moneyOwed
				+ ", noticePref=" + noticePref + ", odPenalty=" + odPenalty
				+ ", pMessage=" + pMessage + ", patronName=" + patronName
				+ ", pcode1=" + pcode1 + ", pcode2=" + pcode2 + ", pcode3="
				+ pcode3 + ", piUse=" + piUse + ", pin=" + pin + ", portal="
				+ portal + ", ptype=" + ptype + ", recInfo=" + recInfo
				+ ", recLeng=" + recLeng + ", recType=" + recType
				+ ", recordNum=" + recordNum + ", revisions=" + revisions
				+ ", sex=" + sex + ", title=" + title + ", totChkout="
				+ totChkout + ", totRenwal=" + totRenwal + ", univId=" + univId
				+ ", updated=" + updated + "]";
	}

	public String getRecInfo() {
		return recInfo;
	}

	public void setRecInfo(String recInfo) {
		this.recInfo = recInfo;
	}

	public Date getExpDate() {
		return expDate;
	}

	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}

	public int getTotChkout() {
		return totChkout;
	}

	public void setTotChkout(int totChkout) {
		this.totChkout = totChkout;
	}

	public int getTotRenwal() {
		return totRenwal;
	}

	public void setTotRenwal(int totRenwal) {
		this.totRenwal = totRenwal;
	}

	public int getCurChkout() {
		return curChkout;
	}

	public void setCurChkout(int curChkout) {
		this.curChkout = curChkout;
	}

	public String getHomeLibr() {
		return homeLibr;
	}

	public void setHomeLibr(String homeLibr) {
		this.homeLibr = homeLibr;
	}

	public String getpMessage() {
		return pMessage;
	}

	public void setpMessage(String pMessage) {
		this.pMessage = pMessage;
	}

	public int getHloDues() {
		return hloDues;
	}

	public void setHloDues(int hloDues) {
		this.hloDues = hloDues;
	}

	public char getMblock() {
		return mblock;
	}

	public void setMblock(char mblock) {
		this.mblock = mblock;
	}

	public char getRecType() {
		return recType;
	}

	public void setRecType(char recType) {
		this.recType = recType;
	}

	public int getRecLeng() {
		return recLeng;
	}

	public void setRecLeng(int recLeng) {
		this.recLeng = recLeng;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public int getRevisions() {
		return revisions;
	}

	public void setRevisions(int revisions) {
		this.revisions = revisions;
	}

	public int getAgency() {
		return agency;
	}

	public void setAgency(int agency) {
		this.agency = agency;
	}

	public int getClRtrnd() {
		return clRtrnd;
	}

	public void setClRtrnd(int clRtrnd) {
		this.clRtrnd = clRtrnd;
	}

	public double getMoneyOwed() {
		return moneyOwed;
	}

	public void setMoneyOwed(double moneyOwed) {
		this.moneyOwed = moneyOwed;
	}

	public String getBlkUntil() {
		return blkUntil;
	}

	public void setBlkUntil(String blkUntil) {
		this.blkUntil = blkUntil;
	}

	public int getCurItema() {
		return curItema;
	}

	public void setCurItema(int curItema) {
		this.curItema = curItema;
	}

	public int getCurItemb() {
		return curItemb;
	}

	public void setCurItemb(int curItemb) {
		this.curItemb = curItemb;
	}

	public int getPiUse() {
		return piUse;
	}

	public void setPiUse(int piUse) {
		this.piUse = piUse;
	}

	public int getOdPenalty() {
		return odPenalty;
	}

	public void setOdPenalty(int odPenalty) {
		this.odPenalty = odPenalty;
	}

	public int getIllChkout() {
		return illChkout;
	}

	public void setIllChkout(int illChkout) {
		this.illChkout = illChkout;
	}

	public Date getCircActive() {
		return circActive;
	}

	public void setCircActive(Date circActive) {
		this.circActive = circActive;
	}

	public char getNoticePref() {
		return noticePref;
	}

	public void setNoticePref(char noticePref) {
		this.noticePref = noticePref;
	}

	public String getPatronName() {
		return patronName;
	}

	public void setPatronName(String patronName) {
		this.patronName = patronName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public String getUnivId() {
		return univId;
	}

	public void setUnivId(String univId) {
		this.univId = univId;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public char getLinkrec() {
		return linkrec;
	}

	public void setLinkrec(char linkrec) {
		this.linkrec = linkrec;
	}

	public List<String> getHoldList() {
		return holdList;
	}

	public void setHoldList(List<String> holdList) {
		this.holdList = holdList;
	}

	public List<String> getBarcodeList() {
		return barcodeList;
	}

	public void setBarcodeList(List<String> barcodeList) {
		this.barcodeList = barcodeList;
	}

	public int getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(int recordNum) {
		this.recordNum = recordNum;
	}

	public String getPcode1() {
		return pcode1;
	}

	public void setPcode1(String pcode1) {
		this.pcode1 = pcode1;
	}

	public String getPcode2() {
		return pcode2;
	}

	public void setPcode2(String pcode2) {
		this.pcode2 = pcode2;
	}

	public String getPcode3() {
		return pcode3;
	}

	public void setPcode3(String pcode3) {
		this.pcode3 = pcode3;
	}
}
