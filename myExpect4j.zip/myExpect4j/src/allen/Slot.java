package allen;

/**
 * Used in OpacSearch_2k.java, InventoryTransfer.java
 * A slot in the review file list
 *
 * @author allen
 *
 */
public class Slot implements Comparable<Slot> {
	private String id;
	private String slotName;
	private String owner;
	private int size;

	public Slot() {

	}

	public Slot(String id, String slotName, String owner, int size) {
		this.id = id;
		this.slotName = slotName;
		this.owner = owner;
		this.size = size;
	}

	@Override
	public int compareTo(Slot o) {
		return 0;
	}

	@Override
	public String toString() {
		return "Slot [id=" + id + ", owner=" + owner + ", size=" + size
				+ ", slotName=" + slotName + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSlotName() {
		return slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

}