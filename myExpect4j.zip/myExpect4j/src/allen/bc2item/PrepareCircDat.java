package allen.bc2item;

/**
 * A project to be used with Offline Mill
 * 
 * Modify item barcode list by adding prefix n:
 * Save output file to Mill Offline folder, filename = circ.dat
 *
 * Define config in inventoryTransfer.properties
 *
 * steps:
 * 1. modify barcode list by adding prefix n:
 * 2. file named as circ.dat, store in Mill Offline Circ
 * 3. upload circ.dat by Mill Offline Circ
 * 4. run GenItemListFromBarcode.java to convert uploaded data into a review list
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-15
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class PrepareCircDat {

	static String infilename;
	static String outfilename;
	static Configuration config;
	private static final Logger logger;

	static {
		String curDir = System.getProperty("user.dir");
		String slash = System.getProperty("file.separator");
		logger = Logger.getLogger(PrepareCircDat.class.getName());
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
		try {
			config = new PropertiesConfiguration(curDir + slash
					+ "inventoryTransfer.properties");
			infilename = config.getString("infilename");
			outfilename = config.getString("circDatFilename");
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
		infilename = curDir + slash + "data" + slash + infilename;
	}

	public static void main(String[] args) {
		PrepareCircDat pc = new PrepareCircDat();
		pc.run();
	}

	private void run() {
		if (!new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}
		int count = 0;
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));
			BufferedWriter out = new BufferedWriter(new FileWriter(outfilename));
			String str;
			while ((str = in.readLine()) != null) {
				if (str.equals("BARCODE")) {
					continue;
				}
				out.write("n:" + str);
				out.newLine();
				count++;
			}
			in.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		logger.info(count + " barcodes written to " + outfilename);
	}

}
