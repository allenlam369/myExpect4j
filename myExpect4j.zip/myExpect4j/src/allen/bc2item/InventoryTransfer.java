package allen.bc2item;

/**
 * A project to be used with Offline Mill
 * 
 * Generate item Review File from a list of item barcodes
 * It is not done by search, but by direct injection of inventory file.
 * It is very fast and with fewer errors
 *
 * Define config in inventoryTransfer.properties
 *
 * steps:
 * 1. modify barcode list by adding prefix n:
 * 2. file named as circ.dat, store in Mill Offline Circ
 * 3. upload circ.dat by Mill Offline Circ
 * 4. run this program to convert uploaded data into a review list
 *
 * 1,2 done by PrepareCircDat.java
 * 3 done by AutoIt to call Offline Circ
 * 4 done by InventoryTransfer.java
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-14
 */

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import allen.Commons;
import allen.Slot;
import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;

public class InventoryTransfer {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String login2 = LoginData.getLogin2();
	static String pwd1 = LoginData.getPwd1();
	static String pwd2 = LoginData.getPwd2();

	static String yourInitial;
	static String slotTitle;
	static List<String> inputList = new ArrayList<String>();
	static String infilename;

	// for parsing slot list
	static String regex = "(\\d+) > (\\S*)\\[\\d+;\\d+H(.*)";
	static Pattern pattern = Pattern.compile(regex);

	static Configuration config;
	private static final Logger logger;
	static Expect4j ssh;

	static {
		String curDir = System.getProperty("user.dir");
		String slash = System.getProperty("file.separator");
		logger = Logger.getLogger(InventoryTransfer.class.getName());

		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
		try {
			config = new PropertiesConfiguration(curDir + slash
					+ "inventoryTransfer.properties");

			slotTitle = config.getString("slotTitle");
			yourInitial = config.getString("yourInitial");
			infilename = config.getString("infilename");
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
		infilename = curDir + slash + "data" + slash + infilename;
		slotTitle = yourInitial + " " + slotTitle;
	}

	public static void main(String[] args) {
		InventoryTransfer trans = new InventoryTransfer();
		trans.run();
	}

	private void run() {
		if (!new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}

		inputList = Commons.readInputFileNoSort(infilename);
		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 2 seconds
			ssh.setDefaultTimeout(2000);

			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");
			ssh.expect("C > CIRCULATION subsystem");
			ssh.send("c");
			ssh.expect("Please key your initials :");
			ssh.send(login2 + "\n");
			ssh.expect("Please key your password :");
			ssh.send(pwd2 + "\n");
			ssh.expect("A > ADDITIONAL circulation functions");
			ssh.send("a");
			ssh.expect("P > PROCESS PC transactions");
			ssh.send("p");

			ssh.expect("Please key your initials :");
			ssh.send(login2 + "\r");
			ssh.expect("Please key your password :");
			ssh.send(pwd2 + "\r");

			ssh.expect("C > COMPARE inventory to shelf list");

			// String buf = ssh.getLastState().getBuffer();
			// System.out.println(buf);

			ssh.send("c");

			ssh.expect("T > TRANSFER file of barcodes to a Review File");
			ssh.send("t");

			ssh.expect("to work on");

			String numStr1 = findSuitableSlot();

			System.out.println(numStr1);

			ssh.send(numStr1);

			ssh.expect("Enter Review File Name:");
			ssh.send(slotTitle + "\n");

			ssh.expect("Key a number or");

			String numStr2 = findNewestFile();
			ssh.send(numStr2);
			ssh.expect("Remove transferred file");
			ssh.send("y");

			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");

			ssh.close();

			logger.info("Item review list created, with title=\"" + slotTitle
					+ "\"\n");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Select Review File To Transfer To
	//
	// NAME OWNER CUR RECS MAX RECS
	// 01 > Empty[5;52Hkevin 0 60000[6;1H
	// 02 > Empty[6;68H0 5000[7;1H
	// 03 > Empty[7;68H0 60000[8;1H
	// 04 > Empty[8;53Hgavh 0 25000[9;1H
	// 05 > Empty[9;68H0 10000[10;1H
	// 06 > check-in/westlaw________stella[10;49Hglstella 0 10000[11;1H
	// 07 > Empty[11;52Hlawoh 0 10000[12;1H
	// 08 > Empty[12;68H0 10000[13;1H
	// Select review file to work on :
	/**
	 * Criteria: (1)Must be large enough and empty, (2) preferred to have the
	 * same owner name as the given initial in config file, (3) preferred to
	 * have no owner
	 *
	 * @return
	 */
	private String findSuitableSlot() {
		String buf = ssh.getLastState().getBuffer();

		// debug
		// System.out.println(buf);

		String s1 = StringUtils.substringBetween(buf, "MAX RECS",
				"Select review file");

		// debug
		// System.out.println(s1);

		CopyOnWriteArrayList<Slot> slotList = new CopyOnWriteArrayList<Slot>();

		int count = 1;
		try {
			while (true) {
				// using two digits
				String n1 = Commons.numFormatter2.format(count++);
				String n2 = Commons.numFormatter2.format(count);
				int index1 = s1.indexOf(n1 + " >");
				int index2 = s1.indexOf(n2 + " >");

				// if both starting and ending indexes cannot be found,
				// try use one digit
				if (index1 < 0 && index2 < 0) {
					n1 = n1.substring(1);
					n2 = n2.substring(1);
					index1 = s1.indexOf(n1 + " >");
					index2 = s1.indexOf(n2 + " >");
				}

				// when we come to the last valid row
				if (index1 >= 0 && index2 < 0) {
					index2 = s1.length();
				}
				String s2 = s1.substring(index1, index2);
				s1 = s1.substring(index2);

				// debug
//				System.out.println(s2);

				Matcher matcher = pattern.matcher(s2);
				String id = null;
				String slotName = null;
				String ownerCapacity = null;
				if (matcher.find()) {
					id = matcher.group(1);
					slotName = matcher.group(2).trim();
					ownerCapacity = matcher.group(3);

					String owner = extractOwner(ownerCapacity);
					int capacity = extractCapacity(ownerCapacity);

					// debug
					// System.out.printf("%s|%s|%s|%s\n", id, slotName,
					// owner, capacity);

					Slot slot = new Slot(id, slotName, owner, capacity);
					slotList.add(slot);
				}
			}
		} catch (IndexOutOfBoundsException e) {
			// break out of while loop
		}

		// filter away slot too small to hold our data
		// filter away non-empty slots
		for (Slot es : slotList) {
			if (es.getSize() < inputList.size()
					|| !es.getSlotName().equals("Empty")) {
				// debug
				// System.out.println("remove " + es);

				slotList.remove(es);
			}
		}

		System.out.println("---");
		for (Slot es : slotList) {
			System.out.println(es);
		}

		// find the first slot with same Initial as the user
		// EmptySlot [id=01, owner=kevin, size=60000, slotName=Empty]
		// EmptySlot [id=03, owner=0, size=60000, slotName=Empty]
		Slot freeSlot = null;
		for (Slot es : slotList) {
			if (es.getOwner().equals(yourInitial)) {
				freeSlot = es;
				break;
			}
		}

		if (freeSlot == null) {
			// find the first slot with no owner.
			for (Slot es : slotList) {
				if (es.getOwner().equals("0")) {
					freeSlot = es;
					break;
				}
			}

			// If all slots are owned, return the first one in the list
			if (freeSlot == null) {
				freeSlot = slotList.get(0);
			}
		}

		int result = Integer.parseInt(freeSlot.getId());
		return Commons.numFormatter2.format(result);
	}

	/**
	 * input "glstella           0     10000[11;1H", output 10000
	 *
	 * input "0      5000[7;1H", output 5000
	 *
	 * @param ownerCapacity
	 * @return
	 */
	private static int extractCapacity(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s+");

		// extract the last substring, then get the number prefix
		return Commons.getNumberPrefix(ss[ss.length - 1]);
	}

	/**
	 * input "kevin           0     60000[6;1H", output "kevin"
	 *
	 * input "Empty[9;68H0", output null
	 *
	 * @param owner
	 * @return
	 */
	private static String extractOwner(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s");
		return ss[0];
	}

	// Files To Transfer Date Created # of Items
	// 1 > rdi20100513 13-05-10 07:50PM 2654
	// 2 > rdi1014051714 14-10-11 05:17PM 2
	// 3 > rdi1014051952 14-10-11 05:19PM 2
	// 4 > rdi_b01 17-05-10 03:53PM 479
	// 5 > rdi_b02 17-05-10 04:31PM 479
	// 6 > rdi2009073100 21-07-09 05:23PM 32
	/**
	 * The buffer will contain data like the above. This method is to find out
	 * the id number of the newest file
	 */
	private String findNewestFile() {
		String buf = ssh.getLastState().getBuffer();
		String s1 = StringUtils.substringBetween(buf, "# of Items",
				"Key a number or");

		// System.out.println(s1);

		List<FileUploaded> fileList = new ArrayList<FileUploaded>();

		int count = 1;
		try {
			while (true) {
				int index1 = s1.indexOf(count++ + " >");
				int index2 = s1.indexOf(count + " >");

				// when we come to the last valid row
				if (index1 >= 0 && index2 < 0) {
					index2 = s1.length();
				}
				String s2 = s1.substring(index1, index2);
				s1 = s1.substring(index2);

				// System.out.println(s2);

				// some delimiting spaces will be represented as "[7;25H"
				s2 = s2.replaceAll(";", " ");

				String[] ss = s2.split("\\s+");

				String dateStr = ss[3] + " " + ss[4];

				int num = Commons.getNumberPrefix(ss[5]);

				FileUploaded fu = new FileUploaded(Integer.parseInt(ss[0]),
						ss[2], Commons.parseDateStr(dateStr), num);

				fileList.add(fu);
			}
		} catch (IndexOutOfBoundsException e) {
			// break out of while loop
		}

		Collections.sort(fileList);

		// for (FileUploaded f : fileList) {
		// System.out.println(f);
		// }
		int result = fileList.get(0).id;

		return Commons.numFormatter2.format(result);

	}

}

class FileUploaded implements Comparable<FileUploaded> {
	int id;
	String fn;
	Date date;
	int itemCount;

	public FileUploaded() {

	}

	public FileUploaded(int id, String fn, Date date, int itemCount) {
		this.id = id;
		this.fn = fn;
		this.date = date;
		this.itemCount = itemCount;
	}

	@Override
	public String toString() {
		return "FilesUploaded [date=" + date + ", fn=" + fn + ", id=" + id
				+ ", itemCount=" + itemCount + "]";
	}

	@Override
	/**
	 * sort by Date, from big to small
	 */
	public int compareTo(FileUploaded o) {
		return o.date.compareTo(this.date);
	}
}
