package allen.opacsearch;

import allen.Commons;

public class OpacBarcode2Patron extends OpacSearch {

	public static void main(String[] args) {
		OpacBarcode2Patron gen = new OpacBarcode2Patron();
		gen.init(Commons.Indexed.BARCODE, Commons.RecType.PATRON);
		Thread t = new Thread(gen);
		t.start();
	}

}
