package allen.opacsearch;

import allen.Commons;

public class OpacIsn2Bib extends OpacSearch {

	public static void main(String[] args) {
		OpacIsn2Bib gen = new OpacIsn2Bib();
		gen.init(Commons.Indexed.ISN, Commons.RecType.BIB);
		Thread t = new Thread(gen);
		t.start();
	}
}
