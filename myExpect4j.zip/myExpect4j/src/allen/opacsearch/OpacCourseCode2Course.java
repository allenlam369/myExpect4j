package allen.opacsearch;

import allen.Commons;

public class OpacCourseCode2Course extends OpacSearch {

	public static void main(String[] args) {
		OpacCourseCode2Course gen = new OpacCourseCode2Course();
		gen.init(Commons.Indexed.RESERVE, Commons.RecType.COURSE);
		Thread t = new Thread(gen);
		t.start();
	}

}
