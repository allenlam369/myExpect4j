/**
 * not finished
 */
package allen.opacsearch;

import allen.Commons;

public class OpacCallno2Bib extends OpacSearch {

	public static void main(String[] args) {
		OpacCallno2Bib gen = new OpacCallno2Bib();
		gen.init(Commons.Indexed.CallNum, Commons.RecType.BIB);
		Thread t = new Thread(gen);
		t.start();
	}
}
