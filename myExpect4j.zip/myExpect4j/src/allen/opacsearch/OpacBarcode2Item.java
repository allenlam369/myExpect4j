package allen.opacsearch;

import allen.Commons;

public class OpacBarcode2Item extends OpacSearch {

	public static void main(String[] args) {
		OpacBarcode2Item gen = new OpacBarcode2Item();
		gen.init(Commons.Indexed.BARCODE, Commons.RecType.ITEM);
		Thread t = new Thread(gen);
		t.start();
	}
}
