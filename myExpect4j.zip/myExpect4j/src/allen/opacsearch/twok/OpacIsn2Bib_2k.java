package allen.opacsearch.twok;

import allen.Commons;

public class OpacIsn2Bib_2k extends OpacSearch_2k {

	public static void main(String[] args) {
		OpacIsn2Bib_2k gen = new OpacIsn2Bib_2k();
		gen.init(Commons.Indexed.ISN, Commons.RecType.BIB);
		Thread t = new Thread(gen);
		t.start();
	}
}
