package allen.opacsearch.twok;

/**
 * Generate Review File from OPAC search on indexed key
 * Non-existing records will not be added to the review file
 *
 * Define config in genList.ini
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-27
 */
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile;
import org.ini4j.Wini;

import allen.Commons;
import allen.Slot;
import allen.login.LoginData;
import allen.genlist.GenFromRecNum;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class OpacSearch_2k implements Runnable {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String pwd1 = LoginData.getPwd1();

	static String yourInitial;
	static String slotTitle;
	static List<String> list = new ArrayList<String>();
	static String infilename;
	static String iniFilename = "genList.ini";

	// subject to change by init agruments of different child classes
	// static String propertiesFilaname;
	static Commons.RecType recType;
	static Commons.Indexed indexed;
	static String recTypeKey;
	static String menuCode;
	static String indexedKey;

	// static Configuration config;
	private static final Logger logger;
	static Expect4j ssh;

	// for parsing slot list
	static String regex = "(\\d+) > (\\S*)\\[\\d+;\\d+H(.*)";
	static Pattern pattern = Pattern.compile(regex);
	static List<String> inputList = new ArrayList<String>();

	static String curDir;
	static String slash;

	static {
		logger = Logger.getLogger(GenFromRecNum.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public void init(Commons.Indexed indexed, Commons.RecType rectype) {
		OpacSearch_2k.recType = rectype;
		OpacSearch_2k.indexed = indexed;
		recTypeKey = Commons.keyMap.get(rectype);
		menuCode = Commons.menuCodeMap.get(rectype);
		indexedKey = Commons.indexMap.get(indexed);

		try {
			Wini ini = new Wini(new File(iniFilename));
			Profile.Section ps = ini.get("general");
			yourInitial = ps.get("yourInitial");

			if (indexed.equals(Commons.Indexed.BARCODE)
					&& rectype.equals(Commons.RecType.ITEM)) {
				ps = ini.get("barcode-item");
				slotTitle = ps.get("slotTitle");
				infilename = ps.get("infilename");
			}

			else if (indexed.equals(Commons.Indexed.ISN)
					&& rectype.equals(Commons.RecType.BIB)) {
				ps = ini.get("isn-bib");
				slotTitle = ps.get("slotTitle");
				infilename = ps.get("infilename");
			}

		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		infilename = curDir + slash + "data" + slash + infilename;
//		slotTitle = yourInitial + " " + slotTitle;

	}

	/**
	 * used by another class which call this class's methods
	 */
	public int defineArguments(String initial, String title, String inFn) {
		yourInitial = initial;
		slotTitle = title;
		infilename = inFn;
		if (StringUtils.isEmpty(yourInitial)) {
			return -1;
		}
		if (StringUtils.isEmpty(slotTitle)) {
			return -2;
		}
		if (StringUtils.isEmpty(infilename)) {
			return -3;
		}
		return 0;
	}

	// public static void main(String[] args) {
	// OpacSearch gb = new OpacSearch();
	// gb.run();
	// }

	public void run() {
		if (!new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}

		list = Commons.readInputFileNoSort(infilename);

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 2 seconds
			ssh.setDefaultTimeout(2000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("S > SEARCH the catalogues");
			ssh.send("s");
			ssh.expect("SUMMARY of all");
			ssh.send(recTypeKey);

			for (String str : list) {
				addRec(str);
			}

			ssh.expect("E > EXPORT marked records");
			ssh.send("e");
			ssh.expect("R > Output to REVIEW file");
			ssh.send("r");

			// select the best slot (must be big enough, preferred no owner)
			ssh.expect("Select review file to work on");
			String slot = findSuitableSlot();
			// slot = "01";
			System.out.println(slot);

			if (slot == null) {
				String msg = "Cannot find a suitable empty review list slot to export";
				logger.fatal(msg);
				throw (new Exception(msg));
			}

			ssh.send(slot);
			ssh.expect("Your Name:");
			ssh.send(yourInitial + "\n");
			ssh.expect("Name of File:");
			ssh.send(slotTitle + "\n");
			ssh.expect("Press <SPACE> to continue");
			ssh.send(" ");

			ssh.expect("C > CLEAR list of marked records");
			ssh.send("c");
			ssh.expect("Are you sure");
			ssh.send("y");
			ssh.expect("Press <SPACE> to continue");
			ssh.send(" ");

			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.close();

			String dateTime = getDateTime();
			String msg = String
					.format(
							"%d %s processed. Created review list in slot having title\n\"OPAC %s %s %s\"\n",
							list.size(), indexed, dateTime, slotTitle,
							yourInitial);
			logger.info(msg);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void addRec(String strToSearch) {
		System.out.println(strToSearch);

		try {
			ssh.expect("Change LANGUAGE");
			ssh.send(indexedKey);
			ssh.expect(".... then press the");
			ssh.send(strToSearch + "\n");

			// three possible responses:
			// 0. one unique record found
			// 1. no match found
			// 2. multiple records found, says "x entries found"

			List<Match> pairs = new ArrayList<Match>();
			int index;
			pairs
					.add(new GlobMatch(Commons.resultHeaderMap.get(recType),
							null));
			pairs.add(new GlobMatch("not found", null));
			pairs
					.add(new GlobMatch(
							"Please type the NUMBER of the item you want to see",
							null));
			index = ssh.expect(pairs);

			// System.out.println(ssh.getLastState().getBuffer());

			switch (index) {
			case 0:
				ssh.send("e");
				ssh.expect("Press <SPACE> to continue");
				ssh.send(" ");
				ssh.expect("N > NEW Search");
				ssh.send("n");
				break;
			case 1:
				String msg = "search string not found when processing "
						+ strToSearch;
				logger.info(msg);
				ssh.send("n");
				break;
			case 2:
				logger.info("Multiple matches found: " + strToSearch);
				ssh.send("n");

				// ssh.send("1");
				// ssh.expect("E > Mark item");
				// ssh.send("e");
				// ssh.expect("Press <SPACE> to continue");
				// ssh.send(" ");
				// ssh.expect("N > NEW Search");
				// ssh.send("n");
				break;
			default:
				// sometimes we get null response due to delay in response?

				// msg = "Unidentified response from Innopac when processing "
				// + barcode;
				// logger.error(msg);
				ssh.send("e");
				ssh.expect("Press <SPACE> to continue");
				ssh.send(" ");
				ssh.expect("N > NEW Search");
				ssh.send("n");
			}

			// System.out.println(ssh.getLastState().getBuffer());

		} catch (MalformedPatternException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getDateTime() {
		Date now = new Date();
		return Commons.dateFormatter1.format(now);
	}

	/**
	 * Criteria: (1)Must be large enough and empty, (2) preferred to have the
	 * same owner name as the given initial in config file, (3) preferred to
	 * have no owner
	 *
	 * @return
	 */
	private String findSuitableSlot() {
		String buf = ssh.getLastState().getBuffer();

		String s1 = StringUtils.substringBetween(buf, "MAX RECS",
				"Select review file");

		CopyOnWriteArrayList<Slot> slotList = new CopyOnWriteArrayList<Slot>();

		int count = 1;
		try {
			while (true) {
				String n1 = Commons.numFormatter2.format(count++);
				String n2 = Commons.numFormatter2.format(count);
				int index1 = s1.indexOf(n1 + " >");
				int index2 = s1.indexOf(n2 + " >");

				// when we come to the last valid row
				if (index1 >= 0 && index2 < 0) {
					index2 = s1.length();
				}
				String s2 = s1.substring(index1, index2);
				s1 = s1.substring(index2);

				// System.out.println(s2);

				Matcher matcher = pattern.matcher(s2);
				String id = null;
				String slotName = null;
				String ownerCapacity = null;
				if (matcher.find()) {
					id = matcher.group(1);
					slotName = matcher.group(2).trim();
					ownerCapacity = matcher.group(3);
				}

				String owner = extractOwner(ownerCapacity);
				int capacity = extractCapacity(ownerCapacity);

				// System.out.printf("%s|%s|%s|%s\n", id, slotName,
				// owner, capacity);

				Slot slot = new Slot(id, slotName, owner, capacity);

				slotList.add(slot);
			}
		} catch (IndexOutOfBoundsException e) {
			// break out of while loop
		}

		// filter away slot too small to hold our data
		// filter away non-empty slots
		for (Slot es : slotList) {
			if (es.getSize() < inputList.size()
					|| !es.getSlotName().equals("Empty")) {
				slotList.remove(es);
			}
		}

		System.out.println("---");
		for (Slot es : slotList) {
			System.out.println(es);
		}

		// find the first slot with same Initial as the user
		// EmptySlot [id=01, owner=kevin, size=60000, slotName=Empty]
		// EmptySlot [id=03, owner=0, size=60000, slotName=Empty]
		Slot freeSlot = null;
		for (Slot es : slotList) {
			if (es.getOwner().equals(yourInitial)) {
				freeSlot = es;
				break;
			}
		}

		if (freeSlot == null) {
			// find the first slot with no owner.
			for (Slot es : slotList) {
				if (es.getOwner().equals("0")) {
					freeSlot = es;
					break;
				}
			}

			// If all slots are owned, return the first one in the list
			if (freeSlot == null) {
				freeSlot = slotList.get(0);
			}
		}
		try {
			int result = Integer.parseInt(freeSlot.getId());
			return Commons.numFormatter2.format(result);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	/**
	 * input "glstella           0     10000[11;1H", output 10000
	 *
	 * input "0      5000[7;1H", output 5000
	 *
	 * @param ownerCapacity
	 * @return
	 */
	private static int extractCapacity(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s+");

		// extract the last substring, then get the number prefix
		return Commons.getNumberPrefix(ss[ss.length - 1]);
	}

	/**
	 * input "kevin           0     60000[6;1H", output "kevin"
	 *
	 * input "Empty[9;68H0", output null
	 *
	 * @param owner
	 * @return
	 */
	private static String extractOwner(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s");
		return ss[0];
	}

}
