package allen.opacsearch.twok;

import allen.Commons;

public class OpacBarcode2Item_2k extends OpacSearch_2k {

	public static void main(String[] args) {
		OpacBarcode2Item_2k gen = new OpacBarcode2Item_2k();
		gen.init(Commons.Indexed.BARCODE, Commons.RecType.ITEM);
		Thread t = new Thread(gen);
		t.start();
	}
}
