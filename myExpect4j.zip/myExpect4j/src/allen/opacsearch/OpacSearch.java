package allen.opacsearch;

/**
 * Generate Review File from OPAC search on indexed key
 * Non-existing records will not be added to the review file
 *
 * Define config in genList.ini
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-27
 *
 * programming NOT finished
 */
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile;
import org.ini4j.Wini;

import allen.Commons;
import allen.login.LoginData;
import allen.genlist.GenFromRecNum;
import expect4j.Expect4j;
import expect4j.ExpectState;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class OpacSearch implements Runnable {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String login2 = LoginData.getLogin2();
	static String pwd1 = LoginData.getPwd1();
	static String pwd2 = LoginData.getPwd2();

	static String yourInitial;
	static String reviewListNum;
	static String slotTitle;
	static List<String> list = new ArrayList<String>();
	static List<String> list2 = new ArrayList<String>();
	static List<String> tmpList = new ArrayList<String>();
	static String infilename;
	static String iniFilename = "genList.ini";

	// subject to change by init agruments of different child classes
	// static String propertiesFilaname;
	static Commons.RecType recType;
	static Commons.Indexed indexed;
	static String recTypeKey;
	static String menuCode;
	static String indexedKey;

	// static Configuration config;
	private static final Logger logger;
	static Expect4j ssh;

	// for parsing slot list
	static String regex = "(\\d+) > (\\S*)\\[\\d+;\\d+H(.*)";
	static Pattern pattern = Pattern.compile(regex);
	static List<String> inputList = new ArrayList<String>();

	static String curDir;
	static String slash;

	// for use in addRec()
	List<Match> pairs = new ArrayList<Match>();

	static {
		logger = Logger.getLogger(GenFromRecNum.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public void init(Commons.Indexed indexed, Commons.RecType rectype) {
		OpacSearch.recType = rectype;
		OpacSearch.indexed = indexed;
		recTypeKey = Commons.keyMap.get(rectype);
		menuCode = Commons.menuCodeMap.get(rectype);
		indexedKey = Commons.indexMap.get(indexed);

		boolean exists = (new File(iniFilename)).exists();
		if (exists) {
			try {
				Wini ini = new Wini(new File(iniFilename));
				Profile.Section ps = ini.get("general");
				yourInitial = ps.get("yourInitial");

				if (indexed.equals(Commons.Indexed.BARCODE)
						&& rectype.equals(Commons.RecType.ITEM)) {
					ps = ini.get("barcode-item");
					if (ps != null) {
						slotTitle = ps.get("slotTitle");
						infilename = ps.get("infilename");
						reviewListNum = ps.get("reviewListNum");
					}
				}

				else if (indexed.equals(Commons.Indexed.ISN)
						&& rectype.equals(Commons.RecType.BIB)) {
					ps = ini.get("isn-bib");
					if (ps != null) {
						slotTitle = ps.get("slotTitle");
						infilename = ps.get("infilename");
						reviewListNum = ps.get("reviewListNum");
					}
				}

				else if (indexed.equals(Commons.Indexed.CallNum)
						&& rectype.equals(Commons.RecType.BIB)) {
					ps = ini.get("callno-bib");
					if (ps != null) {
						slotTitle = ps.get("slotTitle");
						infilename = ps.get("infilename");
						reviewListNum = ps.get("reviewListNum");
					}
				}

				else if (indexed.equals(Commons.Indexed.BARCODE)
						&& rectype.equals(Commons.RecType.PATRON)) {
					ps = ini.get("bc-patron");
					if (ps != null) {
						slotTitle = ps.get("slotTitle");
						infilename = ps.get("infilename");
						reviewListNum = ps.get("reviewListNum");
					}
				}

				else if (indexed.equals(Commons.Indexed.RESERVE)
						&& rectype.equals(Commons.RecType.COURSE)) {
					ps = ini.get("coursecode-course");
					if (ps != null) {
						slotTitle = ps.get("slotTitle");
						infilename = ps.get("infilename");
						reviewListNum = ps.get("reviewListNum");
					}
				}

				else {
					System.out.println("UNKNOWN init inputs");
				}

				reviewListNum = Commons.numFormatter3.format(Integer
						.parseInt(reviewListNum));

			} catch (NumberFormatException e) {
				logger.error("incorrect review file number: " + reviewListNum);
			} catch (InvalidFileFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			infilename = curDir + slash + "data" + slash + infilename;
			// slotTitle = yourInitial + " " + slotTitle;

			System.out.println(String.format(
					"slotTitle=%s, infilename=%s, reviewListNum=%s", slotTitle,
					infilename, reviewListNum));

		}

		// ini file not there; GUI app does not use the the ini file
		else {
			System.out.println(iniFilename + " does not exist");
		}

	}

	/**
	 * used by another class, GenList.java, which call this class's methods
	 */
	public int defineArguments(String initial, String title, String slotNum,
			String inFn) {
		yourInitial = initial;
		slotTitle = title;
		reviewListNum = slotNum;
		infilename = inFn;
		if (StringUtils.isEmpty(yourInitial)) {
			return -1;
		}
		if (StringUtils.isEmpty(slotTitle)) {
			return -2;
		}
		if (StringUtils.isEmpty(reviewListNum)) {
			return -3;
		}
		if (StringUtils.isEmpty(infilename)) {
			return -4;
		}
		return 0;
	}

	public void run() {
		list.clear();
		list2.clear();
		tmpList.clear();

		// debug
		// System.out.println("OpacSearch: infilename = " + infilename);

		if (!new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}

		list = Commons.readInputFileIndexedField(infilename);

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 1 second
			ssh.setDefaultTimeout(1000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("S > SEARCH the catalogues");
			ssh.send("s");
			ssh.expect("SUMMARY of all");
			ssh.send(recTypeKey);

			for (String str : list) {
				addRec(str);
			}

			// co-modification error
			// retry failed cases
			// for (String str : list2) {
			// addRec(str);
			// }

			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		GenFromRecNum gen = new GenFromRecNum(tmpList, reviewListNum, recType,
				yourInitial, slotTitle);

		Thread t = new Thread(gen);
		t.start();

		// System.out.println("Done");
	}

	/**
	 * Add record number to a tmpList
	 *
	 * @throws MalformedPatternException
	 */
	private void addRec(String strToSearch) throws MalformedPatternException {
		boolean searchingCourseCode = false;
		boolean searchingCallno = false;
		System.out.println(strToSearch);

		initPairs();
		int index = -1;

		try {
			ssh.expect("Change LANGUAGE");
			ssh.send(indexedKey);

			// debug
			// System.out.println("indexedKey=" + indexedKey + "; recTypeKey="
			// + recTypeKey);

			// extra dialog for callnum
			if (indexedKey
					.equals(Commons.indexMap.get(Commons.Indexed.CallNum))
					&& recTypeKey.equals(Commons.keyMap
							.get(Commons.RecType.BIB))) {
				ssh.expect("S > NEW Search");
				searchingCallno = true;
				// W > Western language materials call number
				// (Dewey/Moys/Blacks)

				index = extraKeysSearchCallno(strToSearch);
			}

			// extra dialogue for course code
			else if (indexedKey.equals(Commons.indexMap
					.get(Commons.Indexed.RESERVE))
					&& recTypeKey.equals(Commons.keyMap
							.get(Commons.RecType.COURSE))) {
				searchingCourseCode = true;
				ssh.expect("C > Retrieve by COURSE");
				ssh.send("c");
			}

			// ------------
			// these steps are included in sub-routine for callno search
			if (!searchingCallno) {
				ssh.expect(".... then press the");
				ssh.send(strToSearch + "\n");
				index = ssh.expect(pairs);
			}

			// debug
			// System.out.println(ssh.getLastState().getBuffer());
			// System.out.println("index = " + index);

			ExpectState es;
			String buf;
			int where;
			String recNum;
			switch (index) {
			case 0:
				es = ssh.getLastState();
				buf = es.getBuffer();
				where = es.getMatchedWhere();
				recNum = buf.substring(where - 26, where - 16).trim()
						.toLowerCase();
				tmpList.add(recNum);

				ssh.send("n");
				break;
			case 1:
				String msg = "search string not found when processing "
						+ strToSearch;
				logger.info(msg);

				if (searchingCourseCode) {
					ssh.send("q");
				}

				else {
					ssh.send("n");
				}

				break;
			case 2:
				logger.info("Multiple matches found: " + strToSearch);

				// choose the first result
				ssh.send("1");

				// if returned index is 0, unique result
				int index2 = ssh.expect(pairs);

				if (index2 == 0) {
					// get record number normally
					es = ssh.getLastState();
					buf = es.getBuffer();

					where = es.getMatchedWhere();
					recNum = buf.substring(where - 26, where - 16).trim()
							.toLowerCase();
					tmpList.add(recNum);
				}

				else {
					// the last attempt to dig into deeper layers
					ssh.send("11");
					int index3 = ssh.expect(pairs);

					logger.info("Found record in deeper layer for "
							+ strToSearch);
					if (index3 == 0) {
						// get record number normally
						es = ssh.getLastState();
						buf = es.getBuffer();
						where = es.getMatchedWhere();
						recNum = buf.substring(where - 26, where - 16).trim()
								.toLowerCase();
						tmpList.add(recNum);
					}

					else {
						logger.info("Record not added for: " + strToSearch);
					}
				}

				ssh.send("n");
				break;

			case 3:
				logger.info("Too many matches found: " + strToSearch);
				// quit for a new search
				ssh.send("q");
				break;
			default:
				// sometimes we get null response due to delay in response?

				list2.add(strToSearch);
				logger.info("retry processing " + strToSearch);

				ssh.send("n");
			}

			// System.out.println(ssh.getLastState().getBuffer());

			// extra dialogue when searching course code
			if (searchingCourseCode) {
				ssh.expect("R > RETURN to library catalog");
				ssh.send("r");
			}

		} catch (MalformedPatternException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// three possible responses:
	// 0. one unique record found
	// 1. no match found
	// 2. multiple records found, says "x entries found"
	private void initPairs() throws MalformedPatternException {
		pairs.add(new GlobMatch(Commons.resultHeaderMap.get(recType), null));
		pairs.add(new GlobMatch("not found", null));
		pairs.add(new GlobMatch(
				"Please type the NUMBER of the item you want to see", null));
		pairs.add(new GlobMatch(
				"D > Stop searching and DISPLAY 5000 entries found", null));
	}

	private int extraKeysSearchCallno(String strToSearch)
			throws MalformedPatternException, Exception {
		int index;
		// W > Western language materials
		ssh.send("w");
		ssh.expect(".... then press the");
		ssh.send(strToSearch + "\n");
		index = ssh.expect(pairs);
		if (index == 0 || index == 2) {
			return index;
		}

		// ----------
		// L > Library of Congress
		if (index == 3) {
			ssh.send("q");
		} else {
			ssh.send("n");
		}
		ssh.expect("N > Call NUMBER");
		ssh.send("n");
		ssh.expect("L > Library of Congress");
		ssh.send("l");
		ssh.expect(".... then press the");
		ssh.send(strToSearch + "\n");
		index = ssh.expect(pairs);
		if (index == 0 || index == 2) {
			return index;
		}
		// ----------
		// A > East Asian call number (LCC)
		if (index == 3) {
			ssh.send("q");
		} else {
			ssh.send("n");
		}
		ssh.expect("N > Call NUMBER");
		ssh.send("n");
		ssh.expect("A > East Asian call number (LCC)");
		ssh.send("a");
		ssh.expect(".... then press the");
		ssh.send(strToSearch + "\n");
		index = ssh.expect(pairs);
		if (index == 0 || index == 2) {
			return index;
		}
		// ----------
		// C > East Asian call number (OLD)
		if (index == 3) {
			ssh.send("q");
		} else {
			ssh.send("n");
		}
		ssh.expect("N > Call NUMBER");
		ssh.send("n");
		ssh.expect("C > East Asian call number (OLD)");
		ssh.send("c");
		ssh.expect(".... then press the");
		ssh.send(strToSearch + "\n");
		index = ssh.expect(pairs);

		return index;
	}

}
