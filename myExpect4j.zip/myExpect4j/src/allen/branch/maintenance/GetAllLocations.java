package allen.branch.maintenance;
/**
 * Use expect to collect all location codes and related info.
 * Write result to txt file.
 */
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;

public class GetAllLocations {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String login2 = LoginData.getLogin2();
	static String pwd1 = LoginData.getPwd1();
	static String pwd2 = LoginData.getPwd2();
	static Expect4j ssh;

	static int totalLocationCount = 372;

	String base = "D:/HKU/allen.notes/";
	String outfilename = base + "loc.branch.name.txt";
	static NumberFormat numFormatter = new DecimalFormat("000");

	static String regex = "1 > Code..3;32H([0-9A-Za-z]{2,5})..4;1H2 > Circulation Address Number\\s(\\d+)..5;1H3 > Branch Name..5;32H([0-9A-Za-z&\\s]*)";

	public static void main(String[] args) {
		GetAllLocations ga = new GetAllLocations();
		ga.run();

	}

	private void run() {
		Pattern pattern = Pattern.compile(regex);
		StringBuilder sb = new StringBuilder();

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 1 second
			ssh.setDefaultTimeout(1000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("A > ADDITIONAL system functions");
			ssh.send("a");
			ssh.expect("F > ALTER system parameters");
			ssh.send("f");
			ssh.expect("S > SYSTEM codes");
			ssh.send("s");

			ssh.expect("Please key your initials");
			ssh.send(login2 + "\n");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\n");

			ssh.expect("Choose one");
			// System.out.println(ssh.getLastState().getBuffer());
			// B > BRANCH (location) codes
			ssh.send("b");

			// test
			// ssh.expect("Key a number");
			// System.out.println(ssh.getLastState().getBuffer());

			for (int i = 1; i <= totalLocationCount; i++) {
				String num = numFormatter.format(i);

				ssh.expect("Key a number");
				ssh.send(num);

				ssh.expect("Key a number");
				String buf = ssh.getLastState().getBuffer();

				// System.out.println(buf);

				Matcher matcher = pattern.matcher(buf);
				if (matcher.find()) {
					String code = matcher.group(1);
					String cirAddNum = matcher.group(2);
					String branchName = matcher.group(3);
					String outStr = String.format("%s\t%s\t%s\t%s", num, code,
							cirAddNum, branchName);

					sb.append(outStr + "\n");
					System.out.println(outStr);
				}
				ssh.send("q");
			}

			ssh.send("q");
			ssh.send("q");
			ssh.send("q");
			ssh.send("q");
			ssh.send("q");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		writeToFile(sb);
	}

	private void writeToFile(StringBuilder sb) {
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(outfilename));
			out.write("Branch#\tBranch_code\tCirc_Address#\tBranch_Name\n");
			out.write(sb.toString());
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
