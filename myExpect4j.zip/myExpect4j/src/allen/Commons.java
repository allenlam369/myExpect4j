package allen;

/**
 * variables and methods shared between other classes
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-12
 */
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

public class Commons {
	public enum RecType {
		BIB, ORDER, CHECKIN, AUTH, ITEM, PATRON, COURSE, VENDOR, INVOICE;
	}

	public enum Indexed {
		AUTHOR, TITLE, SUBJECT, ISN, CallNum, RecordNum, ControlNum, WORD, BARCODE, StackNum, CatSubSet, RESERVE;
	}

	public static DateFormat dateFormatter1 = new SimpleDateFormat(
			"dd-MM-yy hh:mma");
	public static NumberFormat numFormatter1 = new DecimalFormat("0");
	public static NumberFormat numFormatter2 = new DecimalFormat("00");
	public static NumberFormat numFormatter3 = new DecimalFormat("000");

	public static HashMap<RecType, String> keyMap = new HashMap<RecType, String>();
	public static HashMap<RecType, String> menuCodeMap = new HashMap<RecType, String>();
	public static HashMap<Indexed, String> indexMap = new HashMap<Indexed, String>();
	public static HashMap<RecType, String> resultHeaderMap = new HashMap<RecType, String>();

	public static String curDir = System.getProperty("user.dir");
	public static String slash = System.getProperty("file.separator");

	static String matTypeDataFilename = curDir + slash + "conf" + slash
			+ "matType.txt";
	static String ptypeDataFilename = curDir + slash + "conf" + slash
			+ "ptype.txt";
	static String itypeDataFilename = curDir + slash + "conf" + slash
			+ "itype.txt";

	static String regex = "[bocaiprvnXx\\d]\\d{6,11}[\\dXxAa]";
	static Pattern pattern = Pattern.compile(regex);

	// B > BIBLIOGRAPHIC list
	// O > ORDER list
	// C > CHECKIN list (has extra menu)
	// A > AUTHORITY list
	// I > ITEM list
	// P > PATRON list
	// R > COURSE list
	// V > VENDOR list
	// N > INVOICE list
	static {
		keyMap.put(RecType.BIB, "b");
		keyMap.put(RecType.ORDER, "o");
		keyMap.put(RecType.CHECKIN, "c");
		keyMap.put(RecType.AUTH, "a");
		keyMap.put(RecType.ITEM, "i");
		keyMap.put(RecType.PATRON, "p");
		keyMap.put(RecType.COURSE, "r");
		keyMap.put(RecType.VENDOR, "v");
		keyMap.put(RecType.INVOICE, "n");

		menuCodeMap.put(RecType.BIB, "10");
		menuCodeMap.put(RecType.ORDER, "25");
		menuCodeMap.put(RecType.CHECKIN, "13");
		menuCodeMap.put(RecType.AUTH, "04");
		menuCodeMap.put(RecType.ITEM, "27");
		menuCodeMap.put(RecType.PATRON, "24");
		menuCodeMap.put(RecType.COURSE, "07");
		menuCodeMap.put(RecType.VENDOR, "21");
		menuCodeMap.put(RecType.INVOICE, "06");

		// A > AUTHOR
		// T > TITLE
		// S > SUBJECT
		// I > ISN
		// N > Call NUMBER
		// R > RECORD #
		// O > CONTROL #
		// W > English WORD / CHINESE CHARACTER
		// B > BARCODE
		// K > STACK #
		// P > Library Catalogue Subset
		// C > CONNECT to another database
		// L > RESERVE Materials
		// Z > Inter-Library LOAN requests
		indexMap.put(Indexed.AUTHOR, "a");
		indexMap.put(Indexed.TITLE, "t");
		indexMap.put(Indexed.SUBJECT, "s");
		indexMap.put(Indexed.ISN, "i");
		indexMap.put(Indexed.CallNum, "n");
		indexMap.put(Indexed.RecordNum, "r");
		indexMap.put(Indexed.ControlNum, "o");
		indexMap.put(Indexed.WORD, "w");
		indexMap.put(Indexed.BARCODE, "b");
		indexMap.put(Indexed.StackNum, "k");
		indexMap.put(Indexed.CatSubSet, "p");
		indexMap.put(Indexed.RESERVE, "l");

		resultHeaderMap.put(RecType.BIB, "BIBLIOGRAPHIC Information");
		resultHeaderMap.put(RecType.ITEM, "ITEM Information");
		resultHeaderMap.put(RecType.PATRON, "PATRON Information");
		resultHeaderMap.put(RecType.ORDER, "ORDER Information");
		resultHeaderMap.put(RecType.CHECKIN, "CHECKIN Information");
		resultHeaderMap.put(RecType.AUTH, "AUTHORITY Information");
		resultHeaderMap.put(RecType.COURSE, "COURSE Information");
		resultHeaderMap.put(RecType.VENDOR, "VENDOR Information");
		resultHeaderMap.put(RecType.INVOICE, "INVOICE Information");
	}

	public static List<String> readInputFileSort(String infilename) {
		List<String> list = new ArrayList<String>();
		TreeSet<String> set = new TreeSet<String>();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(infilename), "UTF8"));
			String str;
			int count = 0;
			while ((str = in.readLine()) != null) {
				if (isHeading(str)) {
					continue;
				}

				// skip comment lines
				if (str.startsWith("#")) {
					continue;
				}

				String[] ss = str.split("\\s+", 2);
				set.add(ss[0]);

				count++;
			}
			in.close();

			list.addAll(set);

			System.out.printf("Read %d records from %s\n", list.size(),
					infilename + ", sorted");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	public static List<String> readInputFileNoSort(String infilename) {
		List<String> list = new ArrayList<String>();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(infilename), "UTF8"));
			String str;
			int count = 0;
			while ((str = in.readLine()) != null) {
				if (isHeading(str)) {
					continue;
				}

				// skip comment lines
				if (str.startsWith("#")) {
					continue;
				}

				String[] ss = str.split("\\t", 2);
				String recnum = ss[0].trim();
				if (isRecnum(recnum)) {
					list.add(recnum);
					count++;
				}

			}
			in.close();
			System.out.printf("Read %d records from %s\n", list.size(),
					infilename + ", no sort");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * Validate the recnum obtained from text file
	 *
	 * @param string
	 * @return
	 */
	private static boolean isRecnum(String recnum) {
		Matcher matcher = pattern.matcher(recnum);
		if (matcher.find()) {
			return true;
		}
		return false;
	}

	public static List<String> readInputFileIndexedField(String infilename) {
		List<String> list = new ArrayList<String>();

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(infilename), "UTF8"));
			String str;
			int count = 0;
			while ((str = in.readLine()) != null) {
				if (isHeading(str)) {
					continue;
				}

				// skip comment lines
				if (str.startsWith("#")) {
					continue;
				}

				String[] ss = str.split("\\t", 2);
				String indexField = ss[0].trim();
				if (!StringUtils.isEmpty(indexField)) {
					list.add(indexField);
					count++;
				}

			}
			in.close();
			System.out.printf("Read %d records from %s\n", list.size(),
					infilename + ", no sort");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	private static boolean isHeading(String str) {
		if (str.startsWith("RECORD #") || str.startsWith("BARCODE")
				|| str.startsWith("CALL #")) {
			return true;
		}
		return false;
	}

	/**
	 * get the prefix digits and discard the following non-digit chars
	 *
	 * @param str
	 * @return
	 */
	public static int getNumberPrefix(String str) {
		String regex = "([0-9]+).*";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		String data1 = null;
		if (matcher.find()) {
			data1 = matcher.group(1);
		}
		return Integer.parseInt(data1);
	}

	/**
	 * some dateStr will be like "25H17-05-10 03:53PM". Need to remove incorrect
	 * prefix
	 *
	 * @param dateStr
	 * @return
	 */
	public static Date parseDateStr(String dateStr) {
		if (dateStr.length() > 16) {
			dateStr = dateStr.substring(dateStr.length() - 16);
		}
		try {
			return dateFormatter1.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static HashMap<String, String> getMatTypeMap() {
		HashMap<String, String> map = new HashMap<String, String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(
					matTypeDataFilename));
			String str;
			while ((str = in.readLine()) != null) {
				if (str.startsWith("#")) {
					continue;
				}
				String[] ss = str.split("\\|");
				if (ss.length == 2) {
					map.put(ss[0], ss[1]);
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}

	public static HashMap<Integer, String> getPtypeMap() {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(
					matTypeDataFilename));
			String str;
			while ((str = in.readLine()) != null) {
				str = str.trim();
				if (str.startsWith("#") || str.length() == 0) {
					continue;
				}

				String[] ss = str.split(">");
				if (ss.length == 2) {
					String ptype = ss[0].trim();
					String label = ss[1].trim();
					if (ptype.matches("\\d{3}")) {
						int p = Integer.parseInt(ptype);
						map.put(p, label);
					}
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}

	public static HashMap<Integer, String> getItypeMap() {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(
					itypeDataFilename));
			String str;
			while ((str = in.readLine()) != null) {
				str = str.trim();
				if (str.startsWith("#") || str.length() == 0) {
					continue;
				}

				String[] ss = str.split("\\s", 2);
				String itype = ss[0].trim();
				String label = ss[1].trim();
				if (!StringUtils.isEmpty(itype) && StringUtils.isEmpty(label)) {
					int i = Integer.parseInt(itype);
					map.put(i, label);
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}
}
