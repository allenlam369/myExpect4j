package allen.genlist;

/**
 * Generate Review File from a list of record numbers
 * Non-existing records will not be added to the review file
 *
 * Define config in genList.ini
 *
 * Exec its children instead of this one:
 * GenAuthList, GenBibList, GenCheckinList, GenCourseList, GenInvoiceList,
 * GenItemList, GenOrderList, GenPatronList, GenVendorList
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-26
 */
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile;
import org.ini4j.Wini;

import allen.Commons;
import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class GenFromRecNum implements Runnable {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String login2 = LoginData.getLogin2();
	static String pwd1 = LoginData.getPwd1();
	static String pwd2 = LoginData.getPwd2();

	String yourInitial;
	String reviewListNum;
	String slotTitle;
	List<String> list = new ArrayList<String>();
	String infilename;
	String iniFilename = "genList.ini";

	// subject to change by init agruments of different child classes
	// static String propertiesFilaname;
	Commons.RecType recType;
	static String recTypeKey;
	static String menuCode;

	// static protected Configuration config;
	static protected final Logger logger;
	static protected Expect4j ssh;

	static String curDir;
	static String slash;

	static {
		logger = Logger.getLogger(GenFromRecNum.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public void init(Commons.RecType recType) {
		this.recType = recType;
		recTypeKey = Commons.keyMap.get(recType);
		menuCode = Commons.menuCodeMap.get(recType);
		this.list.clear();

		boolean exists = (new File(iniFilename)).exists();
		if (exists) {
			try {
				Wini ini = new Wini(new File(iniFilename));
				Profile.Section ps = ini.get("general");
				yourInitial = ps.get("yourInitial");

				switch (recType) {
				case BIB:
					ps = ini.get("bib");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case ORDER:
					ps = ini.get("order");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case CHECKIN:
					ps = ini.get("checkin");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case AUTH:
					ps = ini.get("auth");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case ITEM:
					ps = ini.get("item");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case PATRON:
					ps = ini.get("patron");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case COURSE:
					ps = ini.get("course");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case VENDOR:
					ps = ini.get("vendor");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				case INVOICE:
					ps = ini.get("invoice");
					reviewListNum = ps.get("reviewListNum");
					slotTitle = ps.get("slotTitle");
					infilename = ps.get("infilename");
					break;
				default:
				}

				reviewListNum = Commons.numFormatter3.format(Integer
						.parseInt(reviewListNum));

			} catch (NumberFormatException e) {
				logger.error("incorrect review file number: " + reviewListNum);
			} catch (InvalidFileFormatException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			infilename = curDir + slash + "data" + slash + infilename;
			slotTitle = yourInitial + " " + slotTitle;

			System.out.println("GenFromRecNum: infilename = " + infilename);

		}

		// ini file not there; GUI app does not use the the ini file
		else {
			System.out.println(iniFilename + " does not exist");

		}

		// change Accounting unit for checkin records
		if (recType.equals(Commons.RecType.CHECKIN)) {
			login2 = LoginData.getLogin2Checkin();
			pwd2 = LoginData.getPwd2Checkin();
		}

	}

	/**
	 * used by another class which call this class's methods
	 */
	public int defineArguments(String initial, String title, String slotNum,
			String inFn) {
		try {
			slotNum = Commons.numFormatter3.format(Integer.parseInt(slotNum));
		} catch (NumberFormatException e) {
			logger.error("incorrect review file number: " + slotNum);
		}
		yourInitial = initial;
		slotTitle = yourInitial + " " + title;
		reviewListNum = slotNum;
		infilename = inFn;
		if (StringUtils.isEmpty(yourInitial)) {
			return -1;
		}
		if (StringUtils.isEmpty(slotTitle)) {
			return -2;
		}
		if (StringUtils.isEmpty(reviewListNum)) {
			return -3;
		}
		if (StringUtils.isEmpty(infilename)) {
			return -4;
		}
		return 0;
	}

	public void run() {
		if (infilename != null && !new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}

		// list is empty, so read input file to get a list
		if (list.size() == 0) {
			list = Commons.readInputFileNoSort(infilename);
		}

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 2 seconds
			ssh.setDefaultTimeout(2000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");
			ssh.expect("M > MANAGEMENT information");
			ssh.send("m");
			ssh.expect("Please key your initials");
			ssh.send(login2 + "\n");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\n");
			ssh.expect("L > Create LISTS of records");
			ssh.send("L");
			ssh.expect("OWNER    CUR RECS  MAX RECS");
			ssh.send(reviewListNum);

			List<Match> pairs = new ArrayList<Match>();
			int index = -1;

			pairs.add(new GlobMatch("N > NEW BOOLEAN search", null));
			pairs.add(new GlobMatch("2 > Create a new file", null));
			pairs.add(new GlobMatch("Checking every 5 seconds", null));
			index = ssh.expect(pairs);

			// System.out.println(ssh.getLastState().getBuffer());
			// System.out.println("index=" + index);

			switch (index) {
			case 0:
				ssh.send("n");
				ssh.expect("Are you sure you want to delete");
				ssh.send("y");
				break;
			case 1:
				ssh.send("2");
				break;
			case 2:
				String msg = "Slot " + reviewListNum
						+ " is in use. Please try other slots";
				logger.fatal(msg);
				throw new Exception(msg);
			default:
				msg = "Unidentified response from Innopac";
				logger.fatal(msg);
				throw new Exception(msg);
			}

			ssh.expect("Choose what kind of list you want to produce");

			ssh.send(recTypeKey);

			// ---------------------------
			// login initial must be in GENSER accounting unit for it to work.
			// Extra dialog page in checkin search
			if (recType.equals(Commons.RecType.CHECKIN)) {
				ssh.expect("R > Checkin RECORD");
				ssh.send("r");
			}
			// ---------------------------

			pairs.clear();
			pairs.add(new GlobMatch("A > APPEND", null));
			pairs.add(new GlobMatch("N > NEW BOOLEAN", null));
			pairs.add(new GlobMatch("Invalid number keyed", null));

			for (int i = 0; i < list.size(); i++) {
				String recnum = list.get(i);
				// System.out.println(recnum);
				if (i > 0) {

					index = ssh.expect(pairs);

					// System.out.println(ssh.getLastState().getBuffer());

					if (index == 0) {
						ssh.send("a");
					} else if (index == 1) {
						ssh.send("n");
						ssh
								.expect("Choose what kind of list you want to produce");
						ssh.send(recTypeKey);
					} else if (index == 2) {
						ssh.send(String.valueOf((char) 27)); // esc
						ssh.send(String.valueOf((char) 27)); // esc
						logger.info(recnum + " - invalid record number");
						continue;
					} else {
						String buf = ssh.getLastState().getBuffer();
						String msg = "Unidentified response from Innopac. match index="
								+ index;
						logger.fatal(msg);
						logger.fatal(buf);
						throw new Exception(msg);
					}
				}
				addRec(recnum);
			}
			// stop holding the slot
			ssh.expect("Choose one");
			ssh.send("q");

			// quit from review list
			ssh.expect("Choose one");
			ssh.send("q");

			ssh.expect("MANAGEMENT INFORMATION");
			ssh.send("q");

			ssh.expect("MAIN MENU");
			ssh.send("q");

			ssh.close();

			taskReport();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void addRec(String recnum) {
		logger.info(recnum);

		try {
			ssh.expect("Enter code in front of desired field");
			ssh.send(menuCode);
			ssh.expect("Enter boolean condition");
			ssh.send("=");
			ssh.expect("RECORD # =");
			ssh.send("." + recnum + "\n");
			ssh.expect("to enter a range for searching");
			ssh.send("\\");
			ssh.expect("Search records contained in another review file");
			ssh.send("n");
			ssh.expect("Enter starting record");
			ssh.send(recnum + "\n");
			ssh.expect("Enter ending");
			ssh.send(recnum + "\n");
			ssh.expect("Is the range correct");
			ssh.send("y");
			ssh.expect("Enter action");
			ssh.send("s");
			ssh.expect("What name would you like");
			ssh.send(slotTitle + "\n");
			ssh.expect("Press <SPACE> to continue");
			ssh.send(" ");
		} catch (MalformedPatternException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void taskReport() {
		String str = String.format("Created review list in slot %s, size %d\n",
				reviewListNum, list.size());
		logger.info(str);
	}

	protected List<String> getList() {
		return list;
	}

	protected void setList(List<String> list) {
		this.list = list;
	}

	protected Commons.RecType getRecType() {
		return recType;
	}

	protected void setRecType(Commons.RecType recType) {
		this.recType = recType;
	}

	protected static String getRecTypeKey() {
		return recTypeKey;
	}

	protected static void setRecTypeKey(String recTypeKey) {
		GenFromRecNum.recTypeKey = recTypeKey;
	}

	protected static String getMenuCode() {
		return menuCode;
	}

	protected static void setMenuCode(String menuCode) {
		GenFromRecNum.menuCode = menuCode;
	}

	protected String getReviewListNum() {
		return reviewListNum;
	}

	protected void setReviewListNum(String reviewListNum) {
		this.reviewListNum = reviewListNum;
	}

	protected String getSlotTitle() {
		return slotTitle;
	}

	protected void setSlotTitle(String slotTitle) {
		this.slotTitle = slotTitle;
	}

	protected String getYourInitial() {
		return yourInitial;
	}

	protected void setYourInitial(String yourInitial) {
		this.yourInitial = yourInitial;
	}

	/**
	 * When arguments are to be read from ini file. Used by children of this
	 * class.
	 */
	public GenFromRecNum() {

	}

	/**
	 * For non-child class uses. Users prepare the list and other arguments
	 * themselves.
	 *
	 * @param recList
	 * @param slotNum
	 * @param rectype
	 * @param initial
	 * @param slotTitle
	 */
	public GenFromRecNum(List<String> recList, String slotNum,
			Commons.RecType rectype, String initial, String slotTitle) {
		this.list = recList;
		this.reviewListNum = slotNum;
		this.recType = rectype;
		this.slotTitle = initial + " " + slotTitle;
		GenFromRecNum.recTypeKey = Commons.keyMap.get(recType);
		GenFromRecNum.menuCode = Commons.menuCodeMap.get(recType);
	}

}
