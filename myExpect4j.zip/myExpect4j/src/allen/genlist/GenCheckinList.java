package allen.genlist;

import allen.Commons;

/**
 * Initial owner must be belonging to Accounting unit: GENSER
 *
 * Define config in genList.ini
 */

public class GenCheckinList extends GenFromRecNum {

	public static void main(String[] args) {
		GenCheckinList gen = new GenCheckinList();
		gen.init(Commons.RecType.CHECKIN);

		Thread t = new Thread(gen);
		t.start();
	}

}
