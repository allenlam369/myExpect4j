package allen.genlist;

import allen.Commons;

/**
 * Define config in genList.ini
 *
 * @author allen
 *
 */
public class GenAuthList extends GenFromRecNum {

	public static void main(String[] args) {
		GenAuthList gen = new GenAuthList();
		gen.init(Commons.RecType.AUTH);

		Thread t = new Thread(gen);
		t.start();
	}
}
