package allen.genlist;

import allen.Commons;

/**
 * Define config in genList.ini
 *
 * @author allen
 *
 */
public class GenBibList extends GenFromRecNum {

	public static void main(String[] args) {
		GenBibList gen = new GenBibList();
		gen.init(Commons.RecType.BIB);

		Thread t = new Thread(gen);
		t.start();
	}
}
