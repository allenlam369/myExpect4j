package allen.genlist;

import allen.Commons;

/**
 * Define config in genList.ini
 *
 * @author allen
 *
 */
public class GenCourseList extends GenFromRecNum {

	public static void main(String[] args) {
		GenCourseList gen = new GenCourseList();
		gen.init(Commons.RecType.COURSE);

		Thread t = new Thread(gen);
		t.start();
	}
}
