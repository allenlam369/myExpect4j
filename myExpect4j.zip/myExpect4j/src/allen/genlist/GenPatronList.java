package allen.genlist;

import allen.Commons;

/**
 * Define config in genList.ini
 *
 * @author allen
 *
 */
public class GenPatronList extends GenFromRecNum {

	public static void main(String[] args) {
		GenPatronList gen = new GenPatronList();
		gen.init(Commons.RecType.PATRON);

		Thread t = new Thread(gen);
		t.start();
	}
}
