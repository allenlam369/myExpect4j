package allen.genlist;

import allen.Commons;

/**
 * Initial owner must be belonging to Accounting unit: GENACQ
 *
 * Define config in genList.ini
 */

public class GenOrderList extends GenFromRecNum {

	public static void main(String[] args) {
		GenOrderList gen = new GenOrderList();
		gen.init(Commons.RecType.ORDER);

		Thread t = new Thread(gen);
		t.start();
	}
}
