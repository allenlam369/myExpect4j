package allen.genlist;

import allen.Commons;

/**
 * Define config in genList.ini
 *
 * @author allen
 *
 */
public class GenItemList extends GenFromRecNum {

	public static void main(String[] args) {
		GenItemList gen = new GenItemList();
		gen.init(Commons.RecType.ITEM);

		Thread t = new Thread(gen);
		t.start();
	}
}
