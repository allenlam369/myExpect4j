package allen.genlist;

import allen.Commons;

/**
 * Initial owner must be belonging to Accounting unit: GENACQ
 */

public class GenInvoiceList extends GenFromRecNum {

	public static void main(String[] args) {
		GenInvoiceList gen = new GenInvoiceList();
		gen.init(Commons.RecType.INVOICE);

		Thread t = new Thread(gen);
		t.start();
	}
}
