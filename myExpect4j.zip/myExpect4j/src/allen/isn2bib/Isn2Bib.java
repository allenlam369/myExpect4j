package allen.isn2bib;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Profile;
import org.ini4j.Wini;

import allen.Commons;
import expect4j.Expect4j;
import expect4j.ExpectState;
import expect4j.ExpectUtils;
import expect4j.matches.Match;
import expect4j.matches.RegExpMatch;

public class Isn2Bib implements Runnable {

	static String site;
	static String login1;
	static String pwd1;

	static String iniFilename = "genList.ini";
	static String infilename;
	static String outfilename;
	static String mode; // defined in ini
	static String matFormat; // [b|6] determined by mode

	// static protected Configuration config;
	static protected final Logger logger;
	static protected Expect4j ssh;

	static String curDir;
	static String slash;
	// matFormat [6|b] : matFormat name [book|ebook]

	static List<Match> pairs1 = new ArrayList<Match>();
	static List<Match> pairs2 = new ArrayList<Match>();
	static List<Match> pairs3 = new ArrayList<Match>();
	static List<Match> pairs4 = new ArrayList<Match>();
	static List<Match> pairsMarc092 = new ArrayList<Match>();

	static HashMap<String, String> matTypeMap;

	static BufferedWriter out;

	static {
		logger = Logger.getLogger(Isn2Bib.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public void init() {
		try {
			Wini ini = new Wini(new File(iniFilename));
			Profile.Section ps = ini.get("general");
			ps = ini.get("isn-bib");
			infilename = ps.get("infilename");
			outfilename = ps.get("outfilename");

			site = ps.get("site");
			login1 = ps.get("login1");
			pwd1 = ps.get("pwd1");
			mode = ps.get("mode");

			if (!mode.equals("p") && !mode.equals("e") && !mode.equals("all")) {
				mode = "all";
			}

			// default is p
			matFormat = (mode.equals("p") ? "6"
					: (mode.equals("e") ? "b" : "p"));

		} catch (InvalidFileFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		infilename = curDir + slash + "data" + slash + infilename;
		outfilename = curDir + slash + "data" + slash + outfilename;

		matTypeMap = Commons.getMatTypeMap();

		// -----------------------------------
		try {
			pairs1.add(new RegExpMatch("Your ISN not found", null));
			pairs1
					.add(new RegExpMatch("([0-9]+) entries found, entries",
							null));
			pairs1.add(new RegExpMatch("([0-9]+) ISN'S found", null));
			pairs1.add(new RegExpMatch(
					"([Bb][\\d]{7}[\\dXx])   .*MAT FORMAT: (.)", null));
			pairs1.add(new RegExpMatch(
					"D > Stop searching and DISPLAY 5000 entries found", null));
			// ------------
			pairs2.add(new RegExpMatch("([Bb][\\d]{7}[\\dXx])", null));
			pairs2.add(new RegExpMatch("[0-9]+ entries found, entries", null));
			pairs2.add(new RegExpMatch("Press <SPACE> to continue", null));
			pairs2
					.add(new RegExpMatch("([0-9]+) entries found, entries",
							null));
			// ------------
			pairs3.add(new RegExpMatch("([Bb][\\d]{7}[\\dXx])", null));
			// ------------
			pairs4.add(new RegExpMatch(
					"([Bb][\\d]{7}[\\dXx])   .*MAT FORMAT: (.)", null));
			pairs4
					.add(new RegExpMatch("([0-9]+) entries found, entries",
							null));
			// ------------
			pairsMarc092.add(new RegExpMatch("092     ([a-zA-Z0-9 \\.\\|]*)",
					null));
		} catch (MalformedPatternException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		Isn2Bib ib = new Isn2Bib();
		ib.init();

		Thread t = new Thread(ib);
		t.start();

	}

	public void run() {
		List<String> list = Commons.readInputFileNoSort(infilename);

		System.out.println("mode=" + mode);

		try {
			out = new BufferedWriter(new FileWriter(outfilename));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 5 seconds
			ssh.setDefaultTimeout(5000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");
			ssh.expect("S > SEARCH the catalogues");
			ssh.send("s");
			ssh.expect("B > BIBLIOGRAPHIC Record");
			ssh.send("b");

			StringBuffer sb = new StringBuffer();
			for (String isn : list) {
				Result result = new Result(isn);
				ssh.expect("I > ISN");
				ssh.send("i");
				ssh.expect("ISN :");
				ssh.send(isn + "\r");

				// ---------------------------------
				if (mode.equals("all")) {
					int index = -1;
					index = ssh.expect(pairs1);

					switch (index) {
					case 0:
						// level 1: index == 0, ISN not found
						break;
					case 1:
					case 2:
						// index == 1, XX entries found
						// index == 2, XX ISN'S found
						try {

							String entryCount = ssh.getLastState().getMatch(1);
							int numOfEntries = Integer.parseInt(entryCount);

							visitEachNodeModeAll(numOfEntries, result);

						} catch (Exception e) {
							result.setNote("Error getting search result");
						}
						break;
					case 3:
						// level 1: index == 3
						sb.setLength(0);
						try {
							String bib = ssh.getLastState().getMatch(1);
							String matFormat = ssh.getLastState().getMatch(2);
							sb.append(bib.toLowerCase() + " ("
									+ matTypeMap.get(matFormat) + ")");
							result.setBib(sb.toString());
						} catch (Exception e) {
							result.setNote("Error getting search result");
						}
						break;
					case 4:
						// level 1: index == 4, too many results
						ssh.send("d");
						result.setNote("bad search, 5000+ entries found");
						break;
					default:
						result.setNote("Error getting search result");
					} // switch

					out.write(result.toStringForAll());
					out.newLine();

				} // if mode=all

				// ---------------------------------
				// for mode p or e
				else {
					int index = -1;
					index = ssh.expect(pairs1);

					// System.out.println("lvl 1, index=" + index);
					switch (index) {
					case 0:
						// level 1: index == 0, ISN not found
						result.setNote("not found");
						// System.out.println(result.toString());
						break;
					case 1:
					case 2:
						// index == 1, XX entries found
						// index == 2, XX ISN'S found
						String entryCount = ssh.getLastState().getMatch(1);
						int numOfEntries = Integer.parseInt(entryCount);

						visitEachNodePnE(numOfEntries, result);

						break;
					case 3:
						// level 1: index == 3
						try {
							String bib = ssh.getLastState().getMatch(1);
							String matFormat = ssh.getLastState().getMatch(2);
							result.setBib(bib.toLowerCase());
							result.setMatType(matTypeMap.get(matFormat));
							getMarc092(result);
						} catch (Exception e) {
							result.setNote("Error getting search result");
						}
						break;
					case 4:
						// level 1: index == 4, too many results
						ssh.send("d");
						result.setNote("bad search, 5000+ entries found");
						break;
					default:
						result.setNote("Error getting search result");
					} // switch

					out.write(result.toString());
					out.newLine();
				} // else mode p or e

				System.out.println(result);

				ssh.expect("Choose one");
				ssh.send("n");
			} // for

			// closing
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");

			ssh.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			out.close();
			System.out.printf("mode=%s. Results written to %s\n", mode,
					outfilename);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 *
	 * @param numOfEntries
	 * @param result
	 * @throws Exception
	 */
	private void visitEachNodeModeAll(int numOfEntries, Result result)
			throws Exception {
		// System.out.println("numOfEntries=" + numOfEntries);

		StringBuffer sb = new StringBuffer();
		for (int i = 1; i <= numOfEntries; i++) {
			// System.out.println("ssh send " + i);
			ssh.send(String.valueOf(i));

			int pairs4Index = ssh.expect(pairs4);

			// System.out.println("pairs4Index=" + pairs4Index);

			// System.out.println(">>>" + ssh.getLastState().getBuffer());

			// unique record found
			if (pairs4Index == 0) {
				String bib = ssh.getLastState().getMatch(1);
				String matFormat = ssh.getLastState().getMatch(2);

				// System.out.println("bib=" + bib);

				if (i > 1) {
					sb.append("; ");
				}
				sb.append(bib.toLowerCase() + " (" + matTypeMap.get(matFormat)
						+ ")");
				// RETURN to Browsing
				ssh.send("r");
				// System.out.println("return1");

			}
			// recursive layer found
			else if (pairs4Index == 1) {
				String nodeCountStr = ssh.getLastState().getMatch(1);
				int nodeCount = Integer.parseInt(nodeCountStr);

				// System.out.println("##processIndex again, nodeCount="
				// + nodeCount);
				// visitEachNode2(nodeCount, result);

				if (i > 1) {
					sb.append("; ");
				}
				sb.append("[" + nodeCount + " entries found]");

			}
			// unknown error
			else {
				result.setNote("Error getting search result");
			}

		} // for
		ssh.send("r");
		// System.out.println("return2");

		result.setBib(sb.toString());

	}

	/**
	 *
	 * @param numOfEntries
	 * @param result
	 * @throws MalformedPatternException
	 * @throws Exception
	 */
	private void visitEachNodePnE(int numOfEntries, Result result)
			throws MalformedPatternException, Exception {
		// limit by matformat
		ssh.send("L");
		ssh.expect("M > Material Format");
		ssh.send("m");
		ssh.expect("Material Format =");
		ssh.send(matFormat);
		ssh.expect("F > Find items with above limits");
		ssh.send("f");

		int index = ssh.expect(pairs2);
		// System.out.println("lvl 2, index=" + index);

		String bib;
		// level 2.0, single entry
		if (index == 0) {
			try {
				bib = ssh.getLastState().getMatch(1);
				result.setBib(bib.toLowerCase());
				result.setMatType(matTypeMap.get(matFormat));
				if (mode.equals("e")) {
					getMarc092(result);
				}
				if (result.getNote().length() == 0) {
					result.setNote(result.getNote() + "(1st in multi entries)");
				} else {
					result
							.setNote(result.getNote()
									+ " (1st in multi entries)");
				}
			} catch (Exception e) {
				result.setNote("Error getting search result");
			}
		}
		// level 2.1, pick 1st from multi
		else if (index == 1) {
			ssh.send("1"); // get first entry
			index = ssh.expect(pairs3);
			// System.out.println("lvl 2, index=" + index);
			try {
				bib = ssh.getLastState().getMatch(1);
				result.setBib(bib.toLowerCase());
				result.setMatType(matTypeMap.get(matFormat));
				if (mode.equals("e")) {
					getMarc092(result);
				}
			} catch (Exception e) {
				result.setNote("Error getting search result");
			}
		}
		// level 2.2, not found
		else if (index == 2) {
			ssh.send(" "); // press SPACE to continue
			result.setNote("not found");
		}
		// recursive layer is found
		else if (index == 3) {
			// String nodeCountStr = ssh.getLastState().getMatch(1);
			// int nodeCount = Integer.parseInt(nodeCountStr);

			result.setNote("(multi entries found)");
		}
		// unknown error
		else {
			result.setNote("Error getting search result");
		}
	}

	/**
	 * Only process if mode==e
	 *
	 * Write value of tag092 into note field
	 *
	 * 092 is call# for printed books, or vendor for ebooks
	 *
	 * @param result
	 * @throws Exception
	 * @throws MalformedPatternException
	 */
	private void getMarc092(Result result) throws MalformedPatternException,
			Exception {
		if (mode.equals("p")) {
			return;
		}
		ssh.expect("T > Display MARC Record");
		ssh.send("t");

		// sometimes fail to match. don't know why
		ssh.expect(pairsMarc092);

		ExpectState state = ssh.getLastState();
		if (state != null) {
			if (state.getMatchedWhere() >= 0) {
				try {
					String m092 = ssh.getLastState().getMatch(1);
					result.setNote(m092.trim());
				} catch (Exception e) {
					result.setNote("Error getting search result");
				}
			}
		}

		ssh.expect("R > RETURN to Browsing");
		ssh.send("r");
	}
}

class Result {
	String isn = "";
	String bib = "";
	String matType = "";
	String note = "";

	// constructor
	public Result(String isn) {
		this.isn = isn;
	}

	// constructor
	public Result(String isn, String matType) {
		this.isn = isn;
		this.matType = matType;
	}

	// constructor
	public Result() {

	}

	protected String getIsn() {
		return isn;
	}

	protected void setIsn(String isn) {
		this.isn = isn;
	}

	protected String getBib() {
		return bib;
	}

	protected void setBib(String bib) {
		this.bib = bib;
	}

	protected String getMatType() {
		return matType;
	}

	protected void setMatType(String matType) {
		this.matType = matType;
	}

	protected String getNote() {
		return note;
	}

	protected void setNote(String note) {
		this.note = note;
	}

	@Override
	// for use when mode=p or e
	public String toString() {
		return isn + "\t" + bib + "\t" + matType + "\t" + note;
	}

	// for use when mode=all
	public String toStringForAll() {
		String s = isn + "\t" + bib + "\t" + note;
		return s;
	}

}
