package allen.visitor;

/**
 * Run this program only ONCE. Renew it when the same range of patrons are recycled again
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GenPinList {

	static String base = "D:/HKU/patron_visitor/";
	private static String outfilename = base + "pin.list.txt";
	static String arr = "23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";
	int pinLen = 6;
	int wantedPin = 100000;

	static List<String> pinList = new ArrayList<String>();

	public static void main(String[] args) {
		GenPinList gp = new GenPinList();
		gp.run();
	}

	private void run() {
		StringBuilder sb = new StringBuilder();
		Random rand = new Random();

		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(outfilename));

			for (int j = 0; j < wantedPin; j++) {
				// gen one pin
				for (int i = 0; i < pinLen; i++) {
					// Random integers that range from from 0 to n-1
					int a = rand.nextInt(arr.length());
					sb.append(arr.charAt(a));
				}
				out.write(sb.toString());
				out.newLine();
				sb.setLength(0);
			}

			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	static public void loadPin() {
		// read all pins into list
		try {
			BufferedReader in = new BufferedReader(new FileReader(outfilename));
			String str;
			while ((str = in.readLine()) != null) {
				pinList.add(str);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Run loadPin() once before running this method. uid can be like "g10001",
	 * or "10001"
	 *
	 * @param uid
	 * @return
	 */
	static public String getPin(String uid) {
		// remove any non digits from uid
		uid = uid.replaceAll("[a-zA-Z]", "");
		if (uid.length() > 0) {
			int num = Integer.parseInt(uid);
			return pinList.get(num);
		} else {
			return "987654";
		}
	}

}
