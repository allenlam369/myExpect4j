package allen.edit.patron;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;

import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class UpdatePmessage {
	static private String site = LoginData.getSite();
	static private String login1 = LoginData.getLogin1();
	static private String login2 = LoginData.getLogin2();
	static private String pwd1 = LoginData.getPwd1();
	static private String pwd2 = LoginData.getPwd2();

	private static final Logger logger;

	static private Expect4j ssh;

	static private String curDir;
	static private String slash;

	private String regex1 = "^u([a-z0-9]{4,10})";
	private String regex2 = "(\\d{2}) PIN\\s{10}";
	Pattern pattern1 = Pattern.compile(regex1);
	Pattern pattern2 = Pattern.compile(regex2);

	static String base = "D:/HKU/Carmen/";
	private static String infilename = base
			+ "wrong.address.20121025.export.test.txt";
	// private static String outfilename = base +
	// "visitor_med_20121008_recyc.csv";

	static private List<Match> pairs = new ArrayList<Match>();

	static {
		logger = Logger.getLogger(UpdatePmessage.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public static void main(String[] args) throws Exception {

		UpdatePmessage ui = new UpdatePmessage();
		ui.run();

	}

	private void run() throws MalformedPatternException {
		initPairs();

		login();

		// also generated the output csv file
		List<String> list = getRecNumList();

		// loop through all records
		for (String s : list) {
			updatePmessage(s);
		}

		logout();
	}

	/**
	 * Get a list of patron record numbers from file
	 *
	 * @return
	 */
	private List<String> getRecNumList() {
		List<String> list = new ArrayList<String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));

			String str;
			while ((str = in.readLine()) != null) {
				if (str.startsWith("RECORD")) {
					continue;
				}
				String[] ss = str.split("\\|");
				list.add(ss[0]);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return list;
	}

	private int updatePmessage(String recnum) {
		try {
			ssh.expect("Record:");
			ssh.send("." + recnum + "\n");

			int index = ssh.expect(pairs);

			switch (index) {
			// success
			case 0:
				// pmessage
				ssh.send("11");
				ssh.expect("PMESSAGE :");
				// c = wrong address
				ssh.send("c");
				ssh.expect("Choose one");

				ssh.send("q");
				ssh.expect("M > MAKE changes to PATRON permanent");
				ssh.send("m");

				logger.info("updated " + recnum);
				return 0;

				// record in use
			case 1:
				// send <SPACE> then quit, to skip this record
				ssh.send(" ");
				ssh.expect("Nearby BARCODES are");
				ssh.send("q");

				logger.info(recnum + ", Record in use");
				return 1;

				// multiple records found, assume the first one is hit
			case 2:
				ssh.send("q");
				logger.info(recnum + ", multi record found");
				return 2;

				// more than one record with same record number, choose the
				// first
			case 3:
				ssh.send("q");
				logger.info(recnum + ", more than one record with same uid");
				return 3;

				// record not found
			case 4:
				ssh.send("q");
				logger.info(recnum + ", record not found");
				return 4;

				// invalid input, press SPACE
			case 5:
				ssh.send(" ");
				logger.info(recnum + ", invalid input");
				return 5;

				// change or quit record?
			case 6:
				ssh.send("q");
				logger.info(recnum + ", change or quit, choose quit");
				return 6;

				// screen too small
			case 7:
				ssh.send(" q q");
				logger.info(recnum + ", screen too small");
				return 7;

				// patron record number is too big?
			case 8:
				ssh.send(" ");
				logger.info(recnum + ", record number too big");
				return 8;

				// unknown error
			default:
				ssh.send("qq");
				logger.info(recnum + ", unknown error");
				return 9;
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public void login() {
		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 0.5 second
			ssh.setDefaultTimeout(500);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("C > CIRCULATION subsystem");
			ssh.send("c");

			ssh.expect("Please key your initials");
			ssh.send(login2 + "\n");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\n");

			ssh.expect("P > PATRON record maintenance");

			ssh.send("p");
			ssh.expect("U > UPDATE a patron record");

			ssh.send("u");
			ssh.expect("P > PATRON record");

			// String buf = ssh.getLastState().getBuffer();
			// System.out.println(buf);

			ssh.send("p");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void logout() {
		try {
			ssh.expect("(RETURN if done)");
			ssh.send("\n");
			ssh.expect("CHANGE record type to be updated or QUIT?");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 0: successfully opened the record
	 *
	 * 1: record in use
	 *
	 * 2: multiple possible records found
	 *
	 * 3: more than one record for the same record numbers
	 *
	 * 4: no record found
	 *
	 * 5: invalid input
	 *
	 * 6: change record or quit
	 *
	 * @throws MalformedPatternException
	 */
	private static void initPairs() throws MalformedPatternException {
		pairs.add(new GlobMatch("To modify a particular field, Key its number",
				null));
		pairs.add(new GlobMatch("Waiting for another update", null));
		pairs.add(new GlobMatch(
				"Please type the NUMBER of the item you want to see", null));
		pairs.add(new GlobMatch("entries found", null));
		pairs.add(new GlobMatch("Your BARCODE not found", null));
		pairs.add(new GlobMatch("This is not a valid field", null));
		pairs.add(new GlobMatch("(c/q)", null));
		pairs.add(new GlobMatch("(needed 24 x 79)", null));
		pairs.add(new GlobMatch("Number is greater than", null));
	}

}
