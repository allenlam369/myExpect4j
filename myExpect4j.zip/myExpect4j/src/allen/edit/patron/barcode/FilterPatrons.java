package allen.edit.patron.barcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;

public class FilterPatrons {

	String exportfilename = "R:/dept-sct/mobile-logs/export.txt";
	String outfilename = "R:/dept-sct/mobile-logs/export.staff.txt";
	String collectedMobileFilename = "R:/dept-sct/mobile-logs/allen.out.txt";

	static Integer[] staffPtype = { 0, 1, 2, 3, 6, 7, 8, 9, 15, 20, 24, 27, 28,
			29, 30, 31, 32, 33, 34, 35, 36, 116, 121, 122, 123, 124, 125 };
	static Set<Integer> staffSet = new TreeSet<Integer>(Arrays
			.asList(staffPtype));

	public static void main(String[] args) {
		FilterPatrons fp = new FilterPatrons();
		fp.run();

	}

	private void run() {
		getExportList();
	}

	private void getExportList() {
		try {
			BufferedReader in = new BufferedReader(new FileReader(
					exportfilename));
			BufferedWriter out = new BufferedWriter(new FileWriter(outfilename));
			String str;
			while ((str = in.readLine()) != null) {
				if (str.startsWith("RECORD")) {
					continue;
				}

				String[] ss = str.split("\\t", 4);

				String recNum = ss[0];
				int ptype = Integer.parseInt(ss[1]);
				String mobile = ss[2];
				String bc = ss[3];

				PatronMobile pm = new PatronMobile(recNum, ptype, mobile, bc);

				// if he is staff, and patron record has no mobile
				if (staffSet.contains(pm.ptype)
						&& StringUtils.isEmpty(pm.mobile)) {
					System.out.println(pm);
					out.write(pm.toString());
					out.newLine();
				}
			}
			in.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

class PatronMobile {
	String recNum;
	int ptype;
	String mobile;
	String barcode;

	public PatronMobile(String recNum, int ptype, String mobile, String barcode) {
		this.recNum = recNum;
		this.ptype = ptype;
		this.mobile = mobile;

		// choose the barcode which is composed of 5 digits
		String[] ss = barcode.split(";");
		for (String s : ss) {
			if (s.matches("\\d{5}")) {
				this.barcode = s;
				break;
			}
		}
		if (StringUtils.isEmpty(this.barcode)) {
			this.barcode = ss[0];
		}
	}

	@Override
	public String toString() {
		return recNum + "\t" + ptype + "\t" + barcode + "\t" + mobile;
	}

}
