package allen.edit.patron.barcode;

/**
 * After running ChkMultiBc, use this class to edit patron records to remove
 * incorrect multi barcodes
 * 
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.oro.text.regex.MalformedPatternException;

import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class EditPatronRemoveIncorrectBc {

	String infilename = "R:/dept-sct/mobile-logs/sms.allen.out/multi.bc.txt";
	static protected Expect4j ssh;
	String site = LoginData.getSite();
	String login1 = LoginData.getLogin1();
	String pwd1 = LoginData.getPwd1();
	String login2 = LoginData.getLogin2();
	String pwd2 = LoginData.getPwd2();

	Map<String, String> map = new HashMap<String, String>();

	public static void main(String[] args) {
		EditPatronRemoveIncorrectBc ep = new EditPatronRemoveIncorrectBc();
		ep.run();
	}

	private void run() {
		getMap();
		doSsh();
	}

	private void doSsh() {
		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 0.5 seconds
			ssh.setDefaultTimeout(500);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");
			ssh.expect("C > CIRCULATION subsystem");
			ssh.send("c");
			ssh.expect("Please key your initials");
			ssh.send(login2 + "\r");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\r");
			ssh.expect("P > PATRON record maintenance");
			ssh.send("p");
			ssh.expect("U > UPDATE a patron record");
			ssh.send("u");
			ssh.expect("P > PATRON record");
			ssh.send("p");

			Set<String> keyset = map.keySet();
			int changed = 0;
			for (String key : keyset) {
				changed = editPatron(key);

				ssh.send("q");

				if (changed > 0) {
					ssh.expect("M > MAKE changes to PATRON permanent");
					ssh.send("m");
				} else {
					ssh.expect("Q > QUIT");
					ssh.send("q");
				}
			}

			ssh.expect("RETURN if done");
			ssh.send("\n");
			ssh.expect("CHANGE record type to be updated or QUIT?");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");

			ssh.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private int editPatron(String key) throws MalformedPatternException,
			Exception {
		System.out.println(key);

		List<Match> pairs1 = new ArrayList<Match>();
		pairs1.add(new GlobMatch("To modify a particular field", null));
		pairs1.add(new GlobMatch("Waiting for another update", null));

		int changed = 0;
		ssh.expect("What PATRON record do you want to update?");
		ssh.send("." + key + "\n");

		String buffer = null;
		int index = ssh.expect(pairs1);
		if (index == 0) {
			buffer = ssh.getLastState().getBuffer();

			// MORE patron data, next page
			ssh.send("m");
			ssh.expect("To modify a particular field");
			buffer = buffer + ssh.getLastState().getBuffer();

			// System.out.println(buffer);

			// build a regex string
			String str = map.get(key);
			String[] ss = str.split(";");

			// delete max 20 dup barcode each time
			int max = ss.length;
			if (max > 20) {
				max = 20;
			}

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < max; i++) {
				if (i > 0) {
					sb.append(".*");
				}
				sb.append("(\\d\\d) SS & Lib BC\\s+");
				sb.append(ss[i]);
			}

			// String regex =
			// "(\\d\\d) SS & Lib BC\\s+00042421.*(\\d\\d) SS & Lib BC\\s+42421.*(\\d\\d) SS & Lib BC\\s+42421";
			String regex = sb.toString();
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(buffer);

			if (matcher.find()) {
				// refresh the screen
				ssh.send("q");
				ssh.expect("R > RETURN");
				ssh.send("r");

				for (int i = max; i >= 1; i--) {
					System.out.println(matcher.group(i));

					int ret1;
					int ret2;
					int ret3;

					// delete dup
					ret1 = ssh.expect("To modify a particular field");
					ssh.send(matcher.group(i));
					ret2 = ssh.expect("<RETURN> to delete field");
					// when there are 3 digits in the field number
					if (ret2 < 0) {
						ssh.send("\n");
						ret2 = ssh.expect("<RETURN> to delete field");
					}
					ssh.send("\n");
					ret3 = ssh.expect("Are you sure");
					ssh.send("y");
					if (ret1 == 0 && ret2 == 0 && ret3 == 0) {
						changed++;
					}
				}
				System.out.println("changed = " + changed);
			}

			else {
				System.out.println("failed to match barcode of " + key);
			}

		}

		// waiting for another update
		else if (index == 1) {
			System.out.println("waiting for another update");
			// Press <SPACE> to continue
			ssh.send(" ");
			ssh.expect("Q > QUIT");
			ssh.send("q");
		}
		// unexpected situation
		else {
			System.out.println("## cannot process " + key);
			// let it timeout
		}

		return changed;
	}

	private void getMap() {
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));
			String str;
			while ((str = in.readLine()) != null) {
				String[] ss = str.split("\\t");
				if (ss.length == 2) {

					// remove any ';' prefix
					if (ss[1].startsWith(";")) {
						ss[1] = ss[1].substring(1);
					}

					map.put(ss[0], ss[1]);
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
