package allen.edit.patron.barcode;

/**
 * Collect user input mobile numbers from the SMS form log.
 * Want to write the mobile numbers back to patron records if the field is empty.
 *
 * 1. run this program to output allen.out.txt
 * 2. load them to review files, export [rec#, ptype, mobile, barcode] as export.txt
 * 3. run filterpatrons.java
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.util.TreeMap;

public class GetMobiles {

	String basePath1 = "R:/dept-sct/mobile-logs/SMS to your Mobile/";
	String basePath2 = "R:/dept-sct/mobile-logs/SMS@HKUL form/";
	String infilename1 = basePath1 + "uiddone.old.txt";
	String infilename2 = basePath1 + "uiddone.txt";
	String outfilename = "R:/dept-sct/mobile-logs/allen.out.txt";

	static DateFormat dateFormatter1 = new SimpleDateFormat("dd-MM-yy");
	static DateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");

	TreeMap<String, Entry> map = new TreeMap<String, Entry>();

	public static void main(String[] args) {
		GetMobiles gm = new GetMobiles();
		gm.run();
	}

	private void run() {
		processLogFile(infilename1);
		processLogFile(infilename2);
		processChangeLog(basePath2);

		staffOnly();

		listMap();

		writeOutFile();
	}

	private void staffOnly() {
		// PatronRecord pr = PatronRecordLoad.getPatronRecord("62936");

	}

	private void writeOutFile() {

		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(outfilename));
			Set<String> set = map.keySet();
			for (String pnum : set) {
				Entry entry = map.get(pnum);
				out.write(entry.toString());
				out.newLine();
			}

			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void listMap() {
		Set<String> set = map.keySet();
		for (String pnum : set) {
			Entry entry = map.get(pnum);
			System.out.println(entry.toString());
		}

		System.out.println("map size = " + map.size());
	}

	/**
	 * files under dir "SMS to your Mobile" file contents like this:
	 * "mobile_change 1060749 97783146 3 16-01-09"
	 *
	 * Let newer entries overwrite older ones
	 *
	 * @param fname
	 */
	private void processLogFile(String fname) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fname));
			String str;
			while ((str = in.readLine()) != null) {
				String[] ss = str.split("\\t");
				if (ss.length == 5) {
					if (ss[0].equals("mobile_change")
							|| ss[0].equals("mobile_add")
							|| ss[0].equals("mobile_change_carrier")) {

						try {
							Date date = dateFormatter1.parse(ss[4]);
							String pnum = ss[1];
							Entry newEntry = new Entry(pnum, ss[2], date);

							if (map.containsKey(pnum)) {
								if (newEntry.isNewerThan(map.get(pnum))) {
									map.put(pnum, newEntry);
								}
							} else {
								map.put(pnum, newEntry);
							}

						} catch (ParseException e) {
							e.printStackTrace();
						}
					}
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void processChangeLog(String dirName) {
		// get file list under a directory
		File dir = new File(dirName);
		String[] filenameArr = dir.list();
		for (String fn : filenameArr) {
			if (fn.startsWith("CHANGE") || fn.startsWith("NEW")) {
				// get date
				int index = fn.indexOf('-');
				String dateStr = fn.substring(index + 1);
				dateStr = dateStr.substring(0, dateStr.length() - 4);

				// System.out.println(dateStr);

				try {
					Date date = dateFormatter2.parse(dateStr);
					processLogFile(fn, date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * files under dir "SMS@HKUL form" file contents like this:
	 * "1368565	97908702	Peoples"
	 *
	 * Let newer entries overwrite older ones
	 *
	 * @param dirName
	 */
	private void processLogFile(String fn, Date date) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(basePath2
					+ fn));
			String str;
			while ((str = in.readLine()) != null) {
				String[] ss = str.split("\\t");
				if (ss.length == 3) {
					String pnum = ss[0];
					Entry newEntry = new Entry(pnum, ss[1], date);

					if (map.containsKey(pnum)) {
						if (newEntry.isNewerThan(map.get(pnum))) {
							map.put(pnum, newEntry);
						}
					} else {
						map.put(pnum, newEntry);
					}
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

class Entry implements Comparable<Entry> {
	String pnum;
	String mobile;
	Date date;
	static DateFormat dateFormatter2 = new SimpleDateFormat("yyyy-MM-dd");

	// constructor
	public Entry(String pnum, String mobile, Date date) {
		this.pnum = pnum;
		this.mobile = mobile;
		this.date = date;
	}

	boolean isNewerThan(Entry e2) {
		if (this.date.after(e2.date)) {
			return true;
		} else {
			return false;
		}
	}

	protected String getPnum() {
		return pnum;
	}

	protected void setPnum(String pnum) {
		this.pnum = pnum;
	}

	protected String getMobile() {
		return mobile;
	}

	protected void setMobile(String mobile) {
		this.mobile = mobile;
	}

	protected Date getDate() {
		return date;
	}

	protected void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {

		return ".p" + pnum + "a" + "\t" + mobile;

		// return "Entry [date=" + dateFormatter2.format(date) + ", mobile="
		// + mobile + ", pnum=" + pnum + "]";
	}

	public int compareTo(Entry o) {
		return this.date.compareTo(o.date);
	}

}
