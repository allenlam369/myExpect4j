package allen.edit.patron.barcode;

/**
 * export RECORD #(PATRON)	SS & Lib BC	P TYPE	MOBILE from Millennium,
 * then run this program to obtain two output files
 * 
 * Use myExpect4j.EditPatronRemoveIncorrectBc to remove the barcodes in multi.bc.txt
 * 
 * Note: the output file multi.bc.txt will not contain multiple bc cases for
 * green card staff (no portal account records)
 * 
 * Note: for checking multi-Bc, some staff has a portal account, has HR data
 * with the old invalid card serial number,
 * but no staff card, with only a green card. Some of them are hourly paid.
 * So, do not count a staff in multi-bc if he has a green card.
 * 
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

public class ChkMultiBc {

	String base = "R:/dept-sct/mobile-logs/sms.allen.out/";
	String infilename = base + "export.all.txt";
	String outfilename1 = base + "multi.bc.txt";

	String infilenameBc = "D:/HKU/patron.loading/out/staff_barcode.txt";

	String regexBc = "Z[0-9A-F]{8,9}";
	String regexA9 = "A9\\d+";

	public static void main(String[] args) {
		ChkMultiBc cd = new ChkMultiBc();
		cd.run();
	}

	private void run() {
		// a map between 8-digit staff number and official barcode
		Map<String, String> map = readBcIntoMap(infilenameBc);

		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));
			BufferedWriter out = new BufferedWriter(
					new FileWriter(outfilename1));
			String str;

			List<String> bcList = new ArrayList<String>();
			String staffNo;

			while ((str = in.readLine()) != null) {
				if (str.startsWith("RECORD")) {
					continue;
				}
				String[] ss = str.split("\\t", 4);
				String bcs = ss[1];

				boolean hasA9Card = false;

				if (!StringUtils.isEmpty(bcs)) {
					bcList.clear();
					staffNo = null;
					String[] bcArr = bcs.split(";");

					// find records having more than one Z-barcode
					// int count = 0;
					for (String bc : bcArr) {
						if (bc.matches(regexBc)) {
							bcList.add(bc);
							// count++;
						}

						if (bc.matches("\\d{8}")) {
							staffNo = bc;
						}

						if (bc.matches(regexA9)) {
							hasA9Card = true;
						}
					}

					// ensure this staff has portal account
					String officialBc = map.get(staffNo);

					// ignore multi-bc problem for staff having A9 cards
					if (bcList.size() > 1 && officialBc != null && !hasA9Card) {
						StringBuilder sb = new StringBuilder();
						sb.append(ss[0] + "\t");

						// used for testing insertion of ';'
						int j = 0;

						for (int i = 0; i < bcList.size(); i++) {

							// don't output official barcodes
							if (bcList.get(i).equals(officialBc)) {
								continue;
							}

							if (j > 0) {
								sb.append(";");
							}
							sb.append(bcList.get(i));
							j++;
						}
						out.write(sb.toString());
						out.newLine();
					}

				}

			}
			in.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("output file: " + outfilename1);
	}

	private Map<String, String> readBcIntoMap(String filename) {
		Map<String, String> map = new HashMap<String, String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(filename));
			String str;
			while ((str = in.readLine()) != null) {
				String[] ss = str.split("\\s+");
				map.put(ss[0], ss[1]);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map;
	}

}
