package allen.edit.patron.barcode;

/**
 * export RECORD #(PATRON)	SS & Lib BC	P TYPE	MOBILE from Millennium
 * then run this program to obtain two output files
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;

public class ChkDupBc {

	String base = "R:/dept-sct/mobile-logs/sms.allen.out/";
	String infilename = base + "export.all.txt";
	String outfilename1 = base + "dup.bc.txt";
	String outfilename2 = base + "dup.mobile.txt";

	public static void main(String[] args) {
		ChkDupBc cd = new ChkDupBc();
		cd.run();
	}

	private void run() {
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));
			BufferedWriter out1 = new BufferedWriter(new FileWriter(
					outfilename1));
			BufferedWriter out2 = new BufferedWriter(new FileWriter(
					outfilename2));
			String str;
			Set<String> set = new TreeSet<String>();
			List<String> dupList = new ArrayList<String>();

			while ((str = in.readLine()) != null) {
				if (str.startsWith("RECORD")) {
					continue;
				}
				String[] ss = str.split("\\t", 4);
				String bc = ss[1];
				String mobile = ss[3];

				if (!StringUtils.isEmpty(bc)) {
					String[] bcArr = bc.split(";");
					set.clear();
					dupList.clear();
					for (String s : bcArr) {
						boolean result = set.add(s);
						if (!result) {
							dupList.add(s);
						}
					}
					if (dupList.size() > 0) {
						out1.write(ss[0] + "\t");
						int i = 0;
						for (String s1 : dupList) {
							if (i > 0) {
								out1.write(";");
							}
							out1.write(s1);
							i++;
						}
						out1.newLine();
					}
				}

				if (!StringUtils.isEmpty(mobile)) {
					String[] moArr = mobile.split(";");
					set.clear();
					dupList.clear();
					for (String s : moArr) {
						boolean result = set.add(s);
						if (!result) {
							dupList.add(s);
						}
					}
					if (dupList.size() > 0) {
						out2.write(ss[0] + "\t");
						int i = 0;
						for (String s1 : dupList) {
							if (i > 0) {
								out2.write(";");
							}
							out2.write(s1);
							i++;
						}
						out2.newLine();
					}
				}
			}
			in.close();
			out1.close();
			out2.close();
			
			System.out.println("output files:");
			System.out.println(outfilename1);
			System.out.println(outfilename2);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
