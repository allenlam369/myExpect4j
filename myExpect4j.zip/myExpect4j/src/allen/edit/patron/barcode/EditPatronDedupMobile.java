package allen.edit.patron.barcode;

/**
 * After running ChkDupBc, use this class to edit patron records to remove
 * dup mobiles
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.oro.text.regex.MalformedPatternException;

import allen.login.LoginData;
import expect4j.Closure;
import expect4j.Expect4j;
import expect4j.ExpectState;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;
import expect4j.matches.RegExpMatch;

public class EditPatronDedupMobile {

	String infilename = "R:/dept-sct/mobile-logs/sms.allen.out/dup.mobile.txt";
	static protected Expect4j ssh;
	String site = LoginData.getSite();
	String login1 = LoginData.getLogin1();
	String pwd1 = LoginData.getPwd1();
	String login2 = LoginData.getLogin2();
	String pwd2 = LoginData.getPwd2();

	Map<String, String> map = new HashMap<String, String>();

	public static void main(String[] args) {
		EditPatronDedupMobile ep = new EditPatronDedupMobile();
		ep.run();
	}

	private void run() {
		getMap();
		doSsh();
	}

	private void doSsh() {
		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 0.5 seconds
			ssh.setDefaultTimeout(500);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");
			ssh.expect("C > CIRCULATION subsystem");
			ssh.send("c");
			ssh.expect("Please key your initials");
			ssh.send(login2 + "\r");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\r");
			ssh.expect("P > PATRON record maintenance");
			ssh.send("p");
			ssh.expect("U > UPDATE a patron record");
			ssh.send("u");
			ssh.expect("P > PATRON record");
			ssh.send("p");

			Set<String> keyset = map.keySet();
			int changed = 0;
			for (String key : keyset) {
				changed = editPatron(key);

				ssh.send("q");

				if (changed > 0) {
					ssh.expect("M > MAKE changes to PATRON permanent");
					ssh.send("m");
				} else {
					ssh.expect("Q > QUIT");
					ssh.send("q");
				}
			}

			ssh.expect("RETURN if done");
			ssh.send("\n");
			ssh.expect("CHANGE record type to be updated or QUIT?");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");
			ssh.expect("Q > QUIT");
			ssh.send("q");

			ssh.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private int editPatron(String key) throws MalformedPatternException,
			Exception {
		int changed = 0;
		ssh.expect("What PATRON record do you want to update?");
		ssh.send("." + key + "\n");

		Closure closure = new Closure() {
			public void run(ExpectState state) {
				state.addVar("inside", "out");
			}
		};
		List<Match> pairs = new ArrayList<Match>();
		List<String> matchedNumbers = new ArrayList<String>();

		String str = map.get(key);
		String[] ss = str.split(";");
		// get the heading numbers we want to delete
		for (String dup : ss) {
			pairs.clear();
			pairs.add(new RegExpMatch("(\\d+) MOBILE\\s+" + dup, closure));
			pairs.add(new GlobMatch("Waiting for another update", null));
			int index = ssh.expect(pairs);
			// matched something...
			if (index == 0) {
				ExpectState state = ssh.getLastState();
				String result = state.getMatch();

				String[] matchedFields = result.split("\\s");
				if (matchedFields[0].matches("\\d+")) {
					matchedNumbers.add(matchedFields[0]);
				}
			}
			// the record is editing by another process
			else if (index == 1) {
				System.out.println(key + " is being edited by other process");
				// Press <SPACE> to continue
				ssh.send(" ");
				ssh.expect("Q > QUIT");
				ssh.send("q");
			}

			// cannot find mobile. dup mobile already removed?
			else {
				System.out.println("no dup mobile: " + dup);
			}
		}

		if (matchedNumbers.size() == ss.length) {
			// delete fields in patron record
			for (int i = matchedNumbers.size() - 1; i >= 0; i--) {
				// System.out.printf("%s\n", matchedNumbers.get(i));
				System.out.printf("deleted field %s from %s\n", matchedNumbers
						.get(i), key);
				ssh.send(matchedNumbers.get(i));
				ssh.expect("<RETURN> to delete field:");
				ssh.send("\n");
				ssh.expect("Are you sure");
				ssh.send("y");
				changed++;
			}
		}

		return changed;
	}

	private void getMap() {
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));
			String str;
			while ((str = in.readLine()) != null) {
				String[] ss = str.split("\\t");
				if (ss.length == 2) {
					map.put(ss[0], ss[1]);
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
