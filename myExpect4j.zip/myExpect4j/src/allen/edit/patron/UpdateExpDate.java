package allen.edit.patron;

/**
 * Used to change Exp Date to yesterday, for invalidating quitted staff records.
 * 
 * find quitted staff by HKU.FindQuittedStaff 
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;

import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class UpdateExpDate {
	static private String site = LoginData.getSite();
	static private String login1 = LoginData.getLogin1();
	static private String login2 = LoginData.getLogin2();
	static private String pwd1 = LoginData.getPwd1();
	static private String pwd2 = LoginData.getPwd2();

	private static final Logger logger;

	static private Expect4j ssh;

	static private String curDir;
	static private String slash;

	private String regex = "(0{1,3})[1-9]\\d+";
	Pattern pattern = Pattern.compile(regex);

	static String base = "D:/HKU/patron.loading/out/";
	private static String infilename = base + "staff_quitted_out.txt";

	static private List<Match> pairs = new ArrayList<Match>();

	static NumberFormat numFormatter = new DecimalFormat("00");
	List<String> listLongUid = new ArrayList<String>();
	List<String> listShortUid = new ArrayList<String>();

	static {
		logger = Logger.getLogger(UpdateExpDate.class.getName());
		curDir = System.getProperty("user.dir");
		slash = System.getProperty("file.separator");
		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
	}

	public static void main(String[] args) throws Exception {

		UpdateExpDate ui = new UpdateExpDate();
		ui.run();

	}

	private void run() throws MalformedPatternException {

		initPairs();
		login();

		// fill longUidList by data from input file
		getRecNumList();

		String[] arrLongUid = (String[]) listLongUid
				.toArray(new String[listLongUid.size()]);
		String[] arrShortUid = new String[arrLongUid.length];

		// create a short uid list for every record
		for (int i = 0; i < arrLongUid.length; i++) {
			arrShortUid[i] = getShortUidFromLongUid(arrLongUid[i]);
		}

		// loop through all records in LongUid
		for (int i = 0; i < arrLongUid.length; i++) {
			// System.out.println(arrLongUid[i]);
			int result = updateExpDate(arrLongUid[i]);
			if (result == 0) {
				arrShortUid[i] = "";
			}
		}

		// loop through all records in ShortUid if it is not empty
		for (int i = 0; i < arrShortUid.length; i++) {
			String shortUid = arrShortUid[i];
			if (!StringUtils.isEmpty(shortUid)) {
				// System.out.println(shortUid);
				updateExpDate(shortUid);
			}
		}

		logout();
	}

	/**
	 * Get a list of patron record numbers from file
	 * 
	 * @return
	 */
	private void getRecNumList() {
		try {
			BufferedReader in = new BufferedReader(new FileReader(infilename));

			String str;
			while ((str = in.readLine()) != null) {
				str = str.trim();
				if (str.matches("\\d{8}")) {
					listLongUid.add(str);
					listShortUid.add(getShortUidFromLongUid(str));
				}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		// return listLongUid;
	}

	private int updateExpDate(String recnum) {
		Calendar cal = Calendar.getInstance();
		// yesterday in int
		cal.add(Calendar.DAY_OF_MONTH, -1);
		int yr = cal.get(Calendar.YEAR);
		int mo = cal.get(Calendar.MONTH);
		int dy = cal.get(Calendar.DAY_OF_MONTH);

		// yesterday in string
		String year = numFormatter.format(yr - 2000);
		String month = numFormatter.format(mo);
		String day = numFormatter.format(dy);

		try {
			ssh.expect("Record:");
			ssh.send(recnum + "\n");

			int index = ssh.expect(pairs);

			switch (index) {
			// success
			case 0:
				ssh.send("01");
				ssh.expect("EXP DATE :");
				ssh.send(day);
				ssh.send(month);
				ssh.send(year);
				ssh.expect("Choose one");

				ssh.send("q");
				ssh.expect("M > MAKE changes to PATRON permanent");
				ssh.send("m");

				logger.info("updated " + recnum);
				return 0;

				// record in use
			case 1:
				// send <SPACE> then quit, to skip this record
				ssh.send(" ");
				ssh.expect("Nearby BARCODES are");
				ssh.send("q");

				logger.info(recnum + ", Record in use");
				return 1;

				// multiple records found, assume the first one is hit
			case 2:
				ssh.send("q");
				logger.info(recnum + ", multi record found");
				return 2;

				// more than one record with same record number, choose the
				// first
			case 3:
				ssh.send("q");
				logger.info(recnum + ", more than one record with same uid");
				return 3;

				// record not found
			case 4:
				ssh.send("q");
				logger.info(recnum + ", record not found");
				return 4;

				// invalid input, press SPACE
			case 5:
				ssh.send(" ");
				logger.info(recnum + ", invalid input");
				return 5;

				// change or quit record?
			case 6:
				ssh.send("q");
				logger.info(recnum + ", change or quit, choose quit");
				return 6;

				// screen too small
			case 7:
				ssh.send(" q q");
				logger.info(recnum + ", screen too small");
				return 7;

				// patron record number is too big?
			case 8:
				ssh.send(" ");
				logger.info(recnum + ", record number too big");
				return 8;

				// unknown error
			default:
				ssh.send("qq");
				logger.info(recnum + ", unknown error");
				return 9;
			}

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public void login() {
		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 0.5 second
			ssh.setDefaultTimeout(500);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("C > CIRCULATION subsystem");
			ssh.send("c");

			ssh.expect("Please key your initials");
			ssh.send(login2 + "\n");
			ssh.expect("Please key your password");
			ssh.send(pwd2 + "\n");

			ssh.expect("P > PATRON record maintenance");

			ssh.send("p");
			ssh.expect("U > UPDATE a patron record");

			ssh.send("u");
			ssh.expect("P > PATRON record");

			// String buf = ssh.getLastState().getBuffer();
			// System.out.println(buf);

			ssh.send("p");

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void logout() {
		try {
			ssh.expect("(RETURN if done)");
			ssh.send("\n");
			ssh.expect("CHANGE record type to be updated or QUIT?");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 0: successfully opened the record
	 * 
	 * 1: record in use
	 * 
	 * 2: multiple possible records found
	 * 
	 * 3: more than one record for the same record numbers
	 * 
	 * 4: no record found
	 * 
	 * 5: invalid input
	 * 
	 * 6: change record or quit
	 * 
	 * @throws MalformedPatternException
	 */
	private static void initPairs() throws MalformedPatternException {
		pairs.add(new GlobMatch("To modify a particular field, Key its number",
				null));
		pairs.add(new GlobMatch("Waiting for another update", null));
		pairs.add(new GlobMatch(
				"Please type the NUMBER of the item you want to see", null));
		pairs.add(new GlobMatch("entries found", null));
		pairs.add(new GlobMatch("Your BARCODE not found", null));
		pairs.add(new GlobMatch("This is not a valid field", null));
		pairs.add(new GlobMatch("(c/q)", null));
		pairs.add(new GlobMatch("(needed 24 x 79)", null));
		pairs.add(new GlobMatch("Number is greater than", null));
	}

	private String getShortUidFromLongUid(String longUid) {
		// remove zeros at the beginning, at most 3 to remove
		Matcher matcher = pattern.matcher(longUid);
		if (matcher.find()) {
			String zeros = matcher.group(1);
			String shortUid = longUid.replace(zeros, "");
			return shortUid;
		}

		// no zero prefix, return original string
		return longUid;
	}

}
