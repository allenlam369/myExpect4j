/*
 * GenReview.java
 *
 * Created on 2011-10-26
 */

package allen.gui;

import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import allen.Commons;
import allen.genlist.GenFromRecNum;
import allen.opacsearch.OpacBarcode2Item;
import allen.opacsearch.OpacBarcode2Patron;
import allen.opacsearch.OpacCallno2Bib;
import allen.opacsearch.OpacCourseCode2Course;
import allen.opacsearch.OpacIsn2Bib;

/**
 *
 * @author Allen Lam
 */
public class GenList extends javax.swing.JFrame {

	private static final long serialVersionUID = 7519247718958629800L;

	/** Creates new form GenReview */
	public GenList() {
		initComponents();
	}

	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jFrame1 = new javax.swing.JFrame();
		jFileChooser1 = new javax.swing.JFileChooser();
		jLabel1 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jComboBox1 = new javax.swing.JComboBox();
		jTextField4 = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();
		menuBar = new javax.swing.JMenuBar();
		fileMenu = new javax.swing.JMenu();
		openMenuItem = new javax.swing.JMenuItem();
		exitMenuItem = new javax.swing.JMenuItem();
		helpMenu = new javax.swing.JMenu();
		contentsMenuItem = new javax.swing.JMenuItem();
		aboutMenuItem = new javax.swing.JMenuItem();

		javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(
				jFrame1.getContentPane());
		jFrame1.getContentPane().setLayout(jFrame1Layout);
		jFrame1Layout.setHorizontalGroup(jFrame1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 400,
				Short.MAX_VALUE));
		jFrame1Layout.setVerticalGroup(jFrame1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 300,
				Short.MAX_VALUE));

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Generate Review Files");
		setAlwaysOnTop(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage("ico/GUI.png"));

		jLabel1.setLabelFor(jTextField1);
		jLabel1.setText("Your initial:");

		jLabel2.setLabelFor(jTextField2);
		jLabel2.setText("Slot title:");

		jLabel3.setLabelFor(jTextField3);
		jLabel3.setText("Review file num:");

		jComboBox1.setMaximumRowCount(10);
		jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Gen bib review file from bib record numbers",
				"Gen item review file from item record numbers",
				"Gen patron review file from patron record numbers",
				"Gen checkin review file from checkin record numbers",
				"Gen order review file from order record numbers",
				"Gen vendor review file from vendor record numbers",
				"Gen invoice review file from invoice record numbers",
				"Gen authority review file from authority record numbers",
				"Gen course review file from course record numbers", "-----",
				"ISN->bib review file", "callno->bib review file",
				"barcodes->item review file", "barcodes->patron review file",
				"course code->course review file" }));
		jComboBox1.addItemListener(new java.awt.event.ItemListener() {
			public void itemStateChanged(java.awt.event.ItemEvent evt) {
				jComboBox1ItemStateChanged(evt);
			}
		});
		jComboBox1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});

		jLabel4.setLabelFor(jTextField4);
		jLabel4.setText("Input filename:");

		jButton1.setText("Start");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btStartClick(evt);
			}
		});

		fileMenu.setMnemonic('F');
		fileMenu.setText("File");

		openMenuItem.setMnemonic('O');
		openMenuItem.setText("Open");
		openMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(openMenuItem);

		exitMenuItem.setMnemonic('x');
		exitMenuItem.setText("Exit");
		exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitMenuItemActionPerformed(evt);
			}
		});
		fileMenu.add(exitMenuItem);

		menuBar.add(fileMenu);

		helpMenu.setMnemonic('H');
		helpMenu.setText("Help");

		contentsMenuItem.setMnemonic('C');
		contentsMenuItem.setText("Contents");
		helpMenu.add(contentsMenuItem);

		aboutMenuItem.setMnemonic('A');
		aboutMenuItem.setText("About");
		aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				aboutMenuItemActionPerformed(evt);
			}
		});
		helpMenu.add(aboutMenuItem);

		menuBar.add(helpMenu);

		setJMenuBar(menuBar);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jComboBox1,
																								0,
																								387,
																								Short.MAX_VALUE)
																						.addGroup(
																								layout
																										.createSequentialGroup()
																										.addGroup(
																												layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jLabel4)
																														.addComponent(
																																jLabel2)
																														.addComponent(
																																jLabel1)
																														.addComponent(
																																jLabel3,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																Short.MAX_VALUE))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addComponent(
																																jTextField1,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																304,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField2,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																304,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField3,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																304,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField4,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																304,
																																javax.swing.GroupLayout.PREFERRED_SIZE)))))
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addGap(
																				182,
																				182,
																				182)
																		.addComponent(
																				jButton1)))
										.addContainerGap()));
		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addComponent(
												jComboBox1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(31, 31, 31)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel1)
														.addComponent(
																jTextField1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel2)
														.addComponent(
																jTextField2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel3)
														.addComponent(
																jTextField3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel4)
														.addComponent(
																jTextField4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addComponent(jButton1)
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		jLabel2.getAccessibleContext().setAccessibleName("Slot Title:");

		pack();
	}// </editor-fold>

	// GEN-END:initComponents

	private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void openMenuItemActionPerformed(java.awt.event.ActionEvent evt) {
		jFileChooser1.setCurrentDirectory(new File(getDataDirectory()));
		int returnVal = jFileChooser1.showOpenDialog(null);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			try {
				jTextField4.setText(jFileChooser1.getSelectedFile()
						.getCanonicalPath());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {
		JOptionPane.showMessageDialog(jFrame1,
				"Developed by Allen Lam, HKUL, 2011");
	}

	private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {
		// int index = this.jComboBox1.getSelectedIndex();

	}

	private void btStartClick(java.awt.event.ActionEvent evt) {
		String curDir = System.getProperty("user.dir");
		String slash = System.getProperty("file.separator");
		String infilename = this.jTextField4.getText();
		if (!infilename.contains(slash)) {
			infilename = curDir + slash + "data" + slash + infilename;
		}

		int index = this.jComboBox1.getSelectedIndex();
		int code;
		GenFromRecNum gen = new GenFromRecNum();
		switch (index) {
		case 0:
			gen.init(Commons.RecType.BIB);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t0 = new Thread(gen);
				t0.start();
			}
			break;
		case 1:
			gen.init(Commons.RecType.ITEM);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t1 = new Thread(gen);
				t1.start();
			}
			break;
		case 2:
			gen.init(Commons.RecType.PATRON);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t2 = new Thread(gen);
				t2.start();
			}
			break;
		case 3:
			gen.init(Commons.RecType.CHECKIN);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t3 = new Thread(gen);
				t3.start();
			}
			break;
		case 4:
			gen.init(Commons.RecType.ORDER);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t4 = new Thread(gen);
				t4.start();
			}
			break;
		case 5:
			gen.init(Commons.RecType.VENDOR);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t5 = new Thread(gen);
				t5.start();
			}
			break;
		case 6:
			gen.init(Commons.RecType.INVOICE);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t6 = new Thread(gen);
				t6.start();
			}
			break;
		case 7:
			gen.init(Commons.RecType.AUTH);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t7 = new Thread(gen);
				t7.start();
			}
			break;
		case 8:
			gen.init(Commons.RecType.COURSE);
			code = gen.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t8 = new Thread(gen);
				t8.start();
			}
			break;
		case 9:
			// chosen "-----"
			break;
		case 10:
			OpacIsn2Bib g2 = new OpacIsn2Bib();
			g2.init(Commons.Indexed.ISN, Commons.RecType.BIB);
			code = g2.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t10 = new Thread(g2);
				t10.start();
			}
			break;
		case 11:
			OpacCallno2Bib g6 = new OpacCallno2Bib();
			g6.init(Commons.Indexed.CallNum, Commons.RecType.BIB);
			code = g6.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t11 = new Thread(g6);
				t11.start();
			}
			break;
		case 12:
			OpacBarcode2Item g3 = new OpacBarcode2Item();
			g3.init(Commons.Indexed.BARCODE, Commons.RecType.ITEM);
			code = g3.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t12 = new Thread(g3);
				t12.start();
			}
			break;
		case 13:
			OpacBarcode2Patron g4 = new OpacBarcode2Patron();
			g4.init(Commons.Indexed.BARCODE, Commons.RecType.PATRON);
			code = g4.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t13 = new Thread(g4);
				t13.start();
			}
			break;
		case 14:
			OpacCourseCode2Course g5 = new OpacCourseCode2Course();
			g5.init(Commons.Indexed.RESERVE, Commons.RecType.COURSE);
			code = g5.defineArguments(this.jTextField1.getText(),
					this.jTextField2.getText(), this.jTextField3.getText(),
					infilename);
			if (code >= 0) {
				Thread t14 = new Thread(g5);
				t14.start();
			}
			break;

		default:
		}
	}

	private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_exitMenuItemActionPerformed
		System.exit(0);
	}// GEN-LAST:event_exitMenuItemActionPerformed

	private String getDataDirectory() {
		String curDir = System.getProperty("user.dir");
		String slash = System.getProperty("file.separator");
		return curDir + slash + "data" + slash;
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new GenList().setVisible(true);
			}
		});
	}

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JMenuItem aboutMenuItem;
	private javax.swing.JMenuItem contentsMenuItem;
	private javax.swing.JMenuItem exitMenuItem;
	private javax.swing.JMenu fileMenu;
	private javax.swing.JMenu helpMenu;
	private javax.swing.JButton jButton1;
	private javax.swing.JComboBox jComboBox1;
	private javax.swing.JFileChooser jFileChooser1;
	private javax.swing.JFrame jFrame1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;
	private javax.swing.JMenuBar menuBar;
	private javax.swing.JMenuItem openMenuItem;
	// End of variables declaration//GEN-END:variables

}