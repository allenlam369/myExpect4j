package allen.login;

/**
 * Not for public view!!!
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 * @author allen 2011-10-17
 */
public class LoginData {
	static private String site = "library.hku.hk";
	static private String login1 = "root";
	static private String pwd1 = "root";

	// ACQ
	static private String login2 = "root2";
	static private String pwd2 = "root2";

	// SER
	static private String login2Checkin = "root3";
	static private String pwd2Checkin = "root3";

	public static String getSite() {
		return site;
	}

	public static String getLogin1() {
		return login1;
	}

	public static String getPwd1() {
		return pwd1;
	}

	public static String getLogin2() {
		return login2;
	}

	public static String getPwd2() {
		return pwd2;
	}

	public static String getLogin2Checkin() {
		return login2Checkin;
	}

	public static String getPwd2Checkin() {
		return pwd2Checkin;
	}
}
