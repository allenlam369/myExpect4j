package test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import allen.Commons;

public class SimpleTest {

	static String infilename = "D:/Allen/java/myExpect4j/data/patron.recnum.txt";

	public static void main(String[] args) {
		SimpleTest st = new SimpleTest();
		// st.run();

		st.run2();
	}

	private void run2() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(infilename), "UTF8"));
			String str;
			while ((str = in.readLine()) != null) {
				// remove BOM
				if (str != null) {
					str = str.trim();
					if (str.startsWith("\uFEFF")) {
						str = str.substring(1);
					}
				}

				System.out.println(str);
			}
			in.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	private void run() {

		List<String> list = Commons.readInputFileNoSort(infilename);
		for (String s : list) {
			System.out.println(s);
		}

	}

}
