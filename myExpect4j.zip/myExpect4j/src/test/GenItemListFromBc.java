package test;

/**
 * Generate Review File from a list of barcode
 * Non-existing records will not be added to the review file
 *
 * Define config in genItemListFromBc.properties
 *
 * @author: Allen Lam
 * @affiliation: Library Systems, University of Hong Kong
 * @date: 2011-10-21
 */
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.oro.text.regex.MalformedPatternException;

import allen.Commons;
import allen.Slot;
import allen.login.LoginData;
import expect4j.Expect4j;
import expect4j.ExpectUtils;
import expect4j.matches.GlobMatch;
import expect4j.matches.Match;

public class GenItemListFromBc implements Runnable {
	static String site = LoginData.getSite();
	static String login1 = LoginData.getLogin1();
	static String pwd1 = LoginData.getPwd1();

	static String yourInitial;
	static String slotTitle;
	static List<String> list = new ArrayList<String>();
	static String infilename;

	static Configuration config;
	private static final Logger logger;
	static Expect4j ssh;

	// for parsing slot list
	static String regex = "(\\d+) > (\\S*)\\[\\d+;\\d+H(.*)";
	static Pattern pattern = Pattern.compile(regex);
	static List<String> inputList = new ArrayList<String>();

	static {
		String curDir = System.getProperty("user.dir");
		String slash = System.getProperty("file.separator");
		logger = Logger.getLogger(GenItemListFromBc.class.getName());

		PropertyConfigurator.configure(curDir + slash + "log4j.properties");
		try {
			config = new PropertiesConfiguration(curDir + slash
					+ "genItemListFromBc.properties");
			yourInitial = config.getString("yourInitial");
			slotTitle = config.getString("slotTitle");
			infilename = config.getString("infilename");
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
		infilename = curDir + slash + "data" + slash + infilename;
	}

	/**
	 * used by another class which call this class's methods
	 */
	public int defineArguments(String initial, String title, String inFn) {
		yourInitial = initial;
		slotTitle = title;
		infilename = inFn;
		if (StringUtils.isEmpty(yourInitial)) {
			return -1;
		}
		if (StringUtils.isEmpty(slotTitle)) {
			return -2;
		}
		if (StringUtils.isEmpty(infilename)) {
			return -3;
		}
		return 0;
	}

	public static void main(String[] args) {
		GenItemListFromBc gb = new GenItemListFromBc();
		gb.run();
	}

	public void run() {
		if (!new File(infilename).exists()) {
			logger.fatal(infilename + " does not exist.");
			return;
		}

		list = Commons.readInputFileNoSort(infilename);

		try {
			ssh = ExpectUtils.SSH(site, login1, pwd1);

			// 2 seconds
			ssh.setDefaultTimeout(2000);
			ssh.expect("VT100");
			ssh.send("v");
			ssh.expect("y/n");
			ssh.send("y");

			ssh.expect("S > SEARCH the catalogues");
			ssh.send("s");
			ssh.expect("I > ITEM Record");
			ssh.send("i");

			for (String isbn : list) {
				addRec(isbn);
			}

			ssh.expect("E > EXPORT marked records");
			ssh.send("e");
			ssh.expect("R > Output to REVIEW file");
			ssh.send("r");

			// select the best slot (must be big enough, preferred no owner)
			ssh.expect("Select review file to work on");
			String slot = findSuitableSlot();
			// slot = "01";
			System.out.println(slot);

			if (slot == null) {
				String msg = "Cannot find a suitable empty review list slot to export";
				logger.fatal(msg);
				throw (new Exception(msg));
			}

			ssh.send(slot);
			ssh.expect("Your Name:");
			ssh.send(yourInitial + "\n");
			ssh.expect("Name of File:");
			ssh.send(slotTitle + "\n");
			ssh.expect("Press <SPACE> to continue");
			ssh.send(" ");

			ssh.expect("C > CLEAR list of marked records");
			ssh.send("c");
			ssh.expect("Are you sure");
			ssh.send("y");
			ssh.expect("Press <SPACE> to continue");
			ssh.send(" ");

			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.expect("Choose one");
			ssh.send("q");
			ssh.close();

			String dateTime = getDateTime();
			String msg = String
					.format(
							"%d barcode processed. Created review list in slot having title\n\"OPAC %s %s %s\"\n",
							list.size(), dateTime, slotTitle, yourInitial);
			logger.info(msg);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void addRec(String barcode) {
		System.out.println(barcode);

		try {
			ssh.expect("B > BARCODE");
			ssh.send("b");
			ssh.expect("Please enter your barcode");
			ssh.send(barcode + "\n");

			// three possible responses:
			// 0. one unique record found
			// 1. multiple records found, says "x entries found"
			// 2. no match found

			List<Match> pairs = new ArrayList<Match>();
			int index;
			pairs.add(new GlobMatch("ITEM Information", null));
			pairs
					.add(new GlobMatch(
							"Please type the NUMBER of the item you want to see",
							null));
			pairs.add(new GlobMatch("Your BARCODE not found", null));
			index = ssh.expect(pairs);

			switch (index) {
			case 0:
				ssh.send("e");
				ssh.expect("Press <SPACE> to continue");
				ssh.send(" ");
				ssh.expect("N > NEW Search");
				ssh.send("n");
				break;
			case 1:
				ssh.send("1");
				ssh.expect("M > MORE ITEM Record");
				ssh.send("e");
				ssh.expect("Press <SPACE> to continue");
				ssh.send(" ");
				ssh.expect("N > NEW Search");
				ssh.send("n");
				break;
			case 2:
				String msg = "barcode not found when processing " + barcode;
				logger.info(msg);
				ssh.send("n");
				break;
			default:
				// sometimes we get null response due to delay in response?

				// msg = "Unidentified response from Innopac when processing "
				// + barcode;
				// logger.error(msg);
				ssh.send("e");
				ssh.expect("Press <SPACE> to continue");
				ssh.send(" ");
				ssh.expect("N > NEW Search");
				ssh.send("n");
			}

			// System.out.println(ssh.getLastState().getBuffer());

		} catch (MalformedPatternException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getDateTime() {
		Date now = new Date();
		return Commons.dateFormatter1.format(now);
	}

	/**
	 * Criteria: (1)Must be large enough and empty, (2) preferred to have the
	 * same owner name as the given initial in config file, (3) preferred to
	 * have no owner
	 *
	 * @return
	 */
	private String findSuitableSlot() {
		String buf = ssh.getLastState().getBuffer();

		String s1 = StringUtils.substringBetween(buf, "MAX RECS",
				"Select review file");

		CopyOnWriteArrayList<Slot> slotList = new CopyOnWriteArrayList<Slot>();

		int count = 1;
		try {
			while (true) {
				String n1 = Commons.numFormatter2.format(count++);
				String n2 = Commons.numFormatter2.format(count);
				int index1 = s1.indexOf(n1 + " >");
				int index2 = s1.indexOf(n2 + " >");

				// when we come to the last valid row
				if (index1 >= 0 && index2 < 0) {
					index2 = s1.length();
				}
				String s2 = s1.substring(index1, index2);
				s1 = s1.substring(index2);

				// System.out.println(s2);

				Matcher matcher = pattern.matcher(s2);
				String id = null;
				String slotName = null;
				String ownerCapacity = null;
				if (matcher.find()) {
					id = matcher.group(1);
					slotName = matcher.group(2).trim();
					ownerCapacity = matcher.group(3);
				}

				String owner = extractOwner(ownerCapacity);
				int capacity = extractCapacity(ownerCapacity);

				// System.out.printf("%s|%s|%s|%s\n", id, slotName,
				// owner, capacity);

				Slot slot = new Slot(id, slotName, owner, capacity);

				slotList.add(slot);
			}
		} catch (IndexOutOfBoundsException e) {
			// break out of while loop
		}

		// filter away slot too small to hold our data
		// filter away non-empty slots
		for (Slot es : slotList) {
			if (es.getSize() < inputList.size() || !es.getSlotName().equals("Empty")) {
				slotList.remove(es);
			}
		}

		System.out.println("---");
		for (Slot es : slotList) {
			System.out.println(es);
		}

		// find the first slot with same Initial as the user
		// EmptySlot [id=01, owner=kevin, size=60000, slotName=Empty]
		// EmptySlot [id=03, owner=0, size=60000, slotName=Empty]
		Slot freeSlot = null;
		for (Slot es : slotList) {
			if (es.getOwner().equals(yourInitial)) {
				freeSlot = es;
				break;
			}
		}

		if (freeSlot == null) {
			// find the first slot with no owner.
			for (Slot es : slotList) {
				if (es.getOwner().equals("0")) {
					freeSlot = es;
					break;
				}
			}

			// If all slots are owned, return the first one in the list
			if (freeSlot == null) {
				freeSlot = slotList.get(0);
			}
		}
		try {
			int result = Integer.parseInt(freeSlot.getId());
			return Commons.numFormatter2.format(result);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	/**
	 * input "glstella           0     10000[11;1H", output 10000
	 *
	 * input "0      5000[7;1H", output 5000
	 *
	 * @param ownerCapacity
	 * @return
	 */
	private static int extractCapacity(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s+");

		// extract the last substring, then get the number prefix
		return Commons.getNumberPrefix(ss[ss.length - 1]);
	}

	/**
	 * input "kevin           0     60000[6;1H", output "kevin"
	 *
	 * input "Empty[9;68H0", output null
	 *
	 * @param owner
	 * @return
	 */
	private static String extractOwner(String ownerCapacity) {
		String[] ss = ownerCapacity.split("\\s");
		return ss[0];
	}

}
